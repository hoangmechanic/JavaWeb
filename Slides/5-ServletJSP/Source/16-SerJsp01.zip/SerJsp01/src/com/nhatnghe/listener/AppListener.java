package com.nhatnghe.listener;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

import com.nhatnghe.entity.HiberUtil;

@WebListener
public class AppListener implements ServletContextListener, HttpSessionListener {
	int visitors = 10000;
	
	@Override
	public void contextDestroyed(ServletContextEvent e) {
		ServletContext application = e.getServletContext();
		Path path = Paths.get(application.getRealPath("/WEB-INF/visitors.txt"));
		try {
			Files.write(path, String.valueOf(visitors).getBytes());
		} 
		catch (Exception e2) {
			e2.printStackTrace();
		}
		System.out.println("AppListener.contextDestroyed()" + application.getRealPath("/WEB-INF/visitors.txt"));
		
		HiberUtil.shutdown();
	}

	@Override
	public void contextInitialized(ServletContextEvent e) {
		ServletContext application = e.getServletContext();
		try {
			Path path = Paths.get(application.getRealPath("/WEB-INF/visitors.txt"));
			visitors = Integer.parseInt(new String(Files.readAllBytes(path)));
			System.out.println("AppListener.contextInitialized()");
		} 
		catch (Exception e2) {
			e2.printStackTrace();
		}
		
		HiberUtil.getSessionFactory();
	}
	@Override
	public void sessionCreated(HttpSessionEvent e) {
		visitors++;
		HttpSession session = e.getSession();
		//session.setMaxInactiveInterval(20);
		ServletContext application = session.getServletContext();
		
		application.setAttribute("visitors", visitors);
		
		System.out.println("AppListener.sessionCreated()");
	}

	@Override
	public void sessionDestroyed(HttpSessionEvent e) {
		System.out.println("AppListener.sessionDestroyed()");
	}

}
