package com.nhatnghe.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/functions.php")
public class FunctionServlet extends HttpServlet{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String message = "Cựu ngoại trưởng Anh Boris Johnson, cựu chủ tịch hạ viện Andrea Leadson hay Bộ trưởng Môi trường Michael Gove là những cái tên tiềm năng.";
		req.setAttribute("message", message);
		
		req.getRequestDispatcher("/WEB-INF/views/functions.jsp").forward(req, resp);
	}
}
