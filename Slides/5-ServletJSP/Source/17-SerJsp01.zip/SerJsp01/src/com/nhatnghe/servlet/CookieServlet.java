package com.nhatnghe.servlet;

import java.io.IOException;
import java.util.Base64;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/cookie.php")
public class CookieServlet extends HttpServlet{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String name = "user";
		String value = new String(Base64.getEncoder().encode("NghiemN".getBytes()));
		// Tạo cookie
		Cookie cookie = new Cookie(name, value);
		cookie.setMaxAge(3*24*60*60); // 3 ngày
		cookie.setPath("/");
		// Gửi về client để lưu
		resp.addCookie(cookie);
		
		req.getRequestDispatcher("/WEB-INF/views/cookie.jsp").forward(req, resp);
	}
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		Cookie[] cookies = req.getCookies();
		if(cookies != null) {
			for(Cookie cookie : cookies) {
				String name = cookie.getName();
				if(name.equals("user")) {
					String value = cookie.getValue();
					String decode = new String(Base64.getDecoder().decode(value.getBytes()));
					req.setAttribute("username", decode);
				}
			}
		}
		req.getRequestDispatcher("/WEB-INF/views/cookie.jsp").forward(req, resp);
	}
}
