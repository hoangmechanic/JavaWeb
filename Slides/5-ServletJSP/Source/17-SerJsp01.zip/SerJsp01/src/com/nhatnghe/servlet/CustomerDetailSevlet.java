package com.nhatnghe.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;

import com.nhatnghe.entity.Customer;
import com.nhatnghe.entity.HiberUtil;

@WebServlet("/user/detail.php")
public class CustomerDetailSevlet extends HttpServlet {
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		Session session = HiberUtil.getSessionFactory().openSession();
		
		String id = req.getParameter("id");
		
		Customer user = session.find(Customer.class, id);
		
		req.setAttribute("user", user);
		req.getRequestDispatcher("/WEB-INF/views/user/detail.jsp").forward(req, resp);
	}
}
