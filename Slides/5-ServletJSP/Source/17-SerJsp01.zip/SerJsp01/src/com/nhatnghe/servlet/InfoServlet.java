package com.nhatnghe.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/test/info.php")
public class InfoServlet extends HttpServlet {
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		System.out.println("ContextPath: " + req.getContextPath());
		System.out.println("Method: " + req.getMethod());
		System.out.println("RequestURL: " + req.getRequestURL());
		System.out.println("RequestURI: " + req.getRequestURI());
		System.out.println("QueryString: " + req.getQueryString());
		System.out.println("Parameter(a): " + req.getParameter("a"));
		System.out.println("Language: " + req.getLocale().getLanguage());
		
		req.getRequestDispatcher("/WEB-INF/views/info.jsp").forward(req, resp);
	}
}
