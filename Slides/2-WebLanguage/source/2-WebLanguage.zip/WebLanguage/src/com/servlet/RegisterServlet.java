package com.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/register.php")
public class RegisterServlet extends HttpServlet{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.getRequestDispatcher("form/register.jsp").forward(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String fullname = req.getParameter("fullname");
		String gender = req.getParameter("gender");
		String country = req.getParameter("country");
		String music = req.getParameter("music");
		String travel = req.getParameter("travel");
		String other = req.getParameter("other");
		String notes = req.getParameter("notes");
		
		System.out.println("Fullname: " + fullname);
		System.out.println("Gender: " + gender);
		System.out.println("Country: " + country);
		System.out.println("Music: " + music);
		System.out.println("Travel: " + travel);
		System.out.println("Other: " + other);
		System.out.println("Notes: " + notes);
		
		req.getRequestDispatcher("form/register.jsp").forward(req, resp);
	}
}
