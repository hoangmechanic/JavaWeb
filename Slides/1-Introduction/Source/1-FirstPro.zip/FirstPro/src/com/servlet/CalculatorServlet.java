package com.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/calculator.php")
public class CalculatorServlet extends HttpServlet{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.getRequestDispatcher("calculator.jsp").forward(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// Đọc giá trị tham số
		String a = req.getParameter("a");
		String b = req.getParameter("b");
		// Chuyển đổi sang số thực
		double x = Double.parseDouble(a);
		double y = Double.parseDouble(b);
		// Tính toán
		double tong = x + y;
		double hieu = x - y;
		double tich = x * y;
		double thuong = x / y;
		// Chuyển sang jsp
		req.setAttribute("a", tong);
		req.setAttribute("b", hieu);
		req.setAttribute("c", tich);
		req.setAttribute("d", thuong);
		// Chuyển tiếp sang jsp
		req.getRequestDispatcher("calculator.jsp").forward(req, resp);
	}
}
