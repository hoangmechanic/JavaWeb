package com.spr.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.spr.bean.Position;
import com.spr.bean.Staff;
import com.spr.bean.Staff2;

@Controller
public class ValidationController {
	@RequestMapping("validation/form.php")
	public String index(Model model) {
		Staff2 bean = new Staff2();	
		model.addAttribute("staff", bean);
		return "validation/form";
	}
	
	@RequestMapping("validation/validate.php")
	public String save(Model model, 
			@Valid @ModelAttribute("staff") Staff2 bean, BindingResult result) {
		if(result.hasErrors()) {
			model.addAttribute("message", "Vui lòng sửa các lỗi sau");
		}
		else {
			model.addAttribute("message", "Mọi thứ đã đúng");
		}
		return "validation/form";
	}
	
	@ModelAttribute("positions")
	public List<Position> getPositions(){
		List<Position> list = new ArrayList<>();
		list.add(new Position("DIR", "Director"));
		list.add(new Position("MAN", "Manager"));
		list.add(new Position("EMP", "Employee"));
		list.add(new Position("SUP", "Supervisor"));
		return list;
	}
	
	@ModelAttribute("hobbies")
	public List<String> getHobbies(){
		List<String> list = new ArrayList<>();
		list.add("Travelling");
		list.add("Music");
		list.add("Food");
		list.add("Others");
		return list;
	}
}
