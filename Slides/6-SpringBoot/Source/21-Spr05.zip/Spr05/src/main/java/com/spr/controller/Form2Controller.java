package com.spr.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.spr.bean.Position;
import com.spr.bean.Staff;

@Controller
public class Form2Controller {
	@RequestMapping("form/advance.php")
	public String index(Model model) {
		Staff bean = new Staff();	
		model.addAttribute("staff", bean);
		//model.addAttribute("positions", getPositions2());
		return "form/advance";
	}
	
	@RequestMapping("form/save2.php")
	public String save(Model model, @ModelAttribute("staff") Staff bean) {
		//model.addAttribute("positions", getPositions2());
		return "form/advance";
	}
	
	public Map<String, String> getPositions(){
		Map<String, String> map = new HashMap<>();
		map.put("DIR", "Director");
		map.put("MAN", "Manager");
		map.put("EMP", "Employee");
		return map;
	}
	@ModelAttribute("positions")
	public List<Position> getPositions2(){
		List<Position> list = new ArrayList<>();
		list.add(new Position("DIR", "Director"));
		list.add(new Position("MAN", "Manager"));
		list.add(new Position("EMP", "Employee"));
		list.add(new Position("SUP", "Supervisor"));
		return list;
	}
}
