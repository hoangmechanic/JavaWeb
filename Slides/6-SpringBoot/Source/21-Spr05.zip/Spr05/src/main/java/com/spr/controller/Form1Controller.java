package com.spr.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.spr.bean.Staff;

@Controller
public class Form1Controller {
	@RequestMapping("form/simple.php")
	public String index(Model model) {
		Staff bean = new Staff();
		bean.setFullname("Nguyễn Nghiệm");
		bean.setPosition("MAN");
		
		model.addAttribute("staff", bean);
		return "form/simple";
	}
	
	@RequestMapping("form/save.php")
	public String save(Model model, @ModelAttribute("staff") Staff bean) {
		return "form/simple";
	}
}
