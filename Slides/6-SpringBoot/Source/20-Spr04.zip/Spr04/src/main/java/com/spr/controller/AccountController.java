package com.spr.controller;

import javax.servlet.http.Cookie;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.spr.dao.CustomerDAO;
import com.spr.entity.Customer;
import com.spr.service.CookieService;

@Controller
public class AccountController {
	@Autowired
	CustomerDAO dao;
	
	@Autowired
	CookieService cookie;
	
	@GetMapping("account/login.php")
	public String login() {
		return "account/login";
	}
	@PostMapping("account/login.php")
	public String login(Model model, 
			@RequestParam("id") String id,
			@RequestParam("password") String pw,
			@RequestParam(name="remember", defaultValue="false") Boolean rm) {
		Customer user = dao.findById(id);
		if(user == null) {
			model.addAttribute("message", "Invalid username!");
		}
		else if(!user.getPassword().equals(pw)) {
			model.addAttribute("message", "Invalid password!");
		}
		else {
			model.addAttribute("message", "Login successfully!");
			
			if(rm == true) {
				cookie.create("uid", id, 30);
				cookie.create("pwd", pw, 30);
			}
			else {
				cookie.delete("uid");
				cookie.delete("pwd");
			}
		}
		return "account/login";
	}
}
