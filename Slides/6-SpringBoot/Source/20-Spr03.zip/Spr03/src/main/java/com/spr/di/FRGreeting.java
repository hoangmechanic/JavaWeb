package com.spr.di;

import org.springframework.stereotype.Component;
import org.springframework.web.context.annotation.RequestScope;


@Component("fr")
public class FRGreeting implements Greeting {

	public FRGreeting() {
		System.out.println("FRGreeting.FRGreeting()");
	}

	@Override
	public String getHello() {
		return "Bujour";
	}

}
