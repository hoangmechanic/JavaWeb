package com.spr.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.spr.di.CookieService;

@Controller
public class CookieController {
	@Autowired
	CookieService cookieService;
	
	@ResponseBody
	@RequestMapping("cookie/create")
	public String create() {
		cookieService.create("user", "NghiemN", 30);
		return "ok";
	}
	
	@ResponseBody
	@RequestMapping("cookie/delete")
	public String delete() {
		cookieService.delete("user");
		return "ok";
	}
	
	@ResponseBody
	@RequestMapping("cookie/read")
	public String read() {
		String value = cookieService.getValue("user", "TeoNV");
		return value;
	}
}
