package com.spr.di;

public class USGreeting implements Greeting {

	@Override
	public String getHello() {
		return "Good morning";
	}

}
