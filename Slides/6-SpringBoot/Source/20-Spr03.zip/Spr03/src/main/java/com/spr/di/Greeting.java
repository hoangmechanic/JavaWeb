package com.spr.di;

public interface Greeting {
	String getHello();
}
