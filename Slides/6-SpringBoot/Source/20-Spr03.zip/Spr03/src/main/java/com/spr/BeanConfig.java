package com.spr;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.context.annotation.RequestScope;

import com.spr.di.Greeting;
import com.spr.di.USGreeting;
import com.spr.di.VNGreeting;

/*
 * IoC = Inversion of Control
 */
@Configuration
public class BeanConfig {
	@RequestScope
	@Bean("us")
	public Greeting getBean1() {
		return new USGreeting();
	}
	@Bean("vn")
	public Greeting getBean2() {
		return new VNGreeting();
	}
}
