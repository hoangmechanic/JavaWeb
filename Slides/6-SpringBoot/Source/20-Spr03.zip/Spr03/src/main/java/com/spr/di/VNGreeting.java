package com.spr.di;

public class VNGreeting implements Greeting {

	@Override
	public String getHello() {
		return "Xin chào";
	}

}
