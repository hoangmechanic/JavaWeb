package com.spr.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.spr.dao.CategoryDAO;
import com.spr.entity.Category;

@Controller
public class CategoryController {
	@Autowired
	CategoryDAO dao;
	
	@RequestMapping("category/index.php")
	public String index(Model model) {
		Category entity = new Category();
		model.addAttribute("item", entity);
		model.addAttribute("list", dao.findAll());
		return "category/index";
	}
	
	@RequestMapping("category/edit/{id}.php")
	public String edit(Model model, @PathVariable("id") Integer id) {
		Category entity = dao.findById(id);
		
		model.addAttribute("item", entity);
		model.addAttribute("list", dao.findAll());
		return "category/index";
	}
	
	@RequestMapping("category/insert.php")
	public String insert(Model model, Category entity) {	
		dao.create(entity);
		
		model.addAttribute("item", new Category());
		model.addAttribute("list", dao.findAll());
		return "category/index";
	}
	
	@RequestMapping("category/update.php")
	public String update(Model model, 
			@ModelAttribute("item") Category entity) {	
		dao.update(entity);
		
		model.addAttribute("list", dao.findAll());
		return "category/index";
	}
	
	@RequestMapping("category/delete.php")
	public String delete(Model model, @RequestParam("id") Integer id) {	
		dao.delete(id);
		
		model.addAttribute("item", new Category());
		model.addAttribute("list", dao.findAll());
		return "category/index";
	}
}
