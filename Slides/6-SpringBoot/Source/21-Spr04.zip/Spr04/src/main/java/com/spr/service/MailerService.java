package com.spr.service;

import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

@Service
public class MailerService {
	@Autowired
	JavaMailSender mailSender;
	String fromEmail = "songlong2k@gmail.com";
	String fromName = "Nguyễn Nghiệm";
	/**
	 * Sending mail
	 * @param to is sender email
	 * @param subject is the subject of the email
	 * @param body is content of the mail
	 * @param others is other email properties ordered from, cc, bcc, attachs
	 */
	public void send(String to, String subject, String body, String...others) {
		MimeMessage mail = mailSender.createMimeMessage();
		try {
			MimeMessageHelper helper = new MimeMessageHelper(mail, true, "utf-8");
			helper.setFrom(fromEmail);
			helper.setTo(to);
			helper.setSubject(subject);
			helper.setText(body, true);
			helper.setReplyTo(fromEmail);
			
			mailSender.send(mail);
			System.out.println("Đã gửi");
		} 
		catch (Exception e) {
			e.printStackTrace();
		}
	}
}
