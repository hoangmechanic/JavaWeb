package com.spr.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.spr.service.MailerService;

@Controller
public class MailerController {
	@Autowired
	MailerService mailer;
	
	@ResponseBody
	@RequestMapping("mailer/send1.php")
	public String send1(Model model) {
		String to = "nghiemn@fpt.edu.vn";
		String subject = "I miss you";
		String body = "Where are you?";
		
		mailer.send(to, subject, body);
		
		return "ok";
	}
}
