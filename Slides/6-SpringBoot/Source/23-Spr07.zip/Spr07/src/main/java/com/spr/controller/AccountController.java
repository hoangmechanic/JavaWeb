package com.spr.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.spr.dao.CustomerDAO;
import com.spr.entity.Customer;

@Controller
public class AccountController {
	@Autowired
	CustomerDAO dao;
	
	@Autowired
	HttpSession session;
	
	@GetMapping("/account/login")
	public String login() {
		return "account/login";
	}
	
	@PostMapping("/account/login")
	public String login(Model model,
			@RequestParam("id") String id, 
			@RequestParam("password") String pw) {
		Customer user = dao.findById(id);
		if(user == null) {
			model.addAttribute("message", "Invalid id");
		}
		else if(!pw.equals(user.getPassword())) {
			model.addAttribute("message", "Invalid password");
		}
		else if(!user.isActivated()) {
			model.addAttribute("message", "Inactivated account");
		}
		else {
			session.setAttribute("user", user);
			model.addAttribute("message", "Login successfully");
			
			String uri = (String) session.getAttribute("security-uri");
			if(uri != null) {
				return "redirect:" + uri;
			}
		}
		return "account/login";
	}
	
	@RequestMapping("/account/register")
	public String register() {
		return "account/register";
	}
	
	@RequestMapping("/account/forgot")
	public String forgot() {
		return "account/forgot";
	}
	
	@RequestMapping("/account/change")
	public String change() {
		return "account/change";
	}
	
	@RequestMapping("/account/edit")
	public String edit() {
		return "account/change";
	}
	
	@RequestMapping("/account/logoff")
	public String logoff() {
		return "account/logoff";
	}
	
	@RequestMapping("/account/activate")
	public String activate() {
		return "account/activate";
	}
}
