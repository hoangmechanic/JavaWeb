package com.spr.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HelloController {
	@RequestMapping("/url1")
	public String method1() {
		System.out.println("HelloController.method1()");
		return "hello";
	}
	
	@RequestMapping("/url2")
	public String method2() {
		return "hello";
	}
	
	@RequestMapping("/url3")
	public String method3() {
		return "hello";
	}
}
