package com.spr;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.spr.inter.AuthInterceptor;
import com.spr.inter.LogInterceptor;

@Configuration
public class InterceptorConfig implements WebMvcConfigurer {
	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		registry.addInterceptor(new LogInterceptor())
			.addPathPatterns("/**")
			.excludePathPatterns("/url2");
		registry.addInterceptor(new AuthInterceptor())
			.addPathPatterns("/account/edit", "/account/change", "/order/**");
	}
}
