$(function(){
	$("a[href*=lang]").click(function(){
		event.preventDefault();
		href = $(this).attr("href");
		$.ajax({
			url: href,
			success: function(response){
				location.reload();
			}
		});
	});
})