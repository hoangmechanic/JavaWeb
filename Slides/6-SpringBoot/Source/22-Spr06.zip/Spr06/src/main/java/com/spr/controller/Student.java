package com.spr.controller;

public class Student {
	String id;
	String name;
	Double mark = 5.0;
	
	public Student() {
		super();
	}

	public Student(String id, String name) {
		this.id= id;
		this.name= name;
	}
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Double getMark() {
		return mark;
	}
	public void setMark(Double mark) {
		this.mark = mark;
	}

}
