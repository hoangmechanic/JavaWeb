package com.spr.controller;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(produces=MediaType.APPLICATION_JSON_UTF8_VALUE)
public class ApiController {
	Map<String, Student> map = new HashMap<>();
	
	ApiController(){
		map.put("SV001", new Student("SV001", "Nguyễn Văn Tèo"));
		map.put("SV002", new Student("SV002", "Phạm Thị Nở"));
	}
	
	@GetMapping("api/get-one/{id}")
	public ResponseEntity<Student> getOne(@PathVariable("id") String id) {
		Student sv = map.get(id);
		return ResponseEntity.ok(sv);
	}
	
	@GetMapping("api/get-all")
	public ResponseEntity<Collection<Student>> getAll() {
		Collection<Student> dssv = map.values();
		return ResponseEntity.ok(dssv);
	}
	
	@PostMapping("api/create")
	public ResponseEntity<Student> post(@RequestBody Student sv) {
		if(map.containsKey(sv.getId())) {
			return ResponseEntity.badRequest().build();
		}
		map.put(sv.getId(), sv);
		return ResponseEntity.ok(sv);
	}
	
	@PutMapping("api/update/{id}")
	public ResponseEntity<Void> put(@RequestBody Student sv, 
			@PathVariable("id") String id) {
		if(!map.containsKey(id)) {
			return ResponseEntity.notFound().build();
		}
		map.put(id, sv);
		return ResponseEntity.ok().build();
	}
	
	@DeleteMapping("api/delete/{id}")
	public ResponseEntity<Void> delete(@PathVariable("id") String id) {
		if(!map.containsKey(id)) {
			return ResponseEntity.notFound().build();
		}
		map.remove(id);
		return ResponseEntity.ok().build();
	}
}
