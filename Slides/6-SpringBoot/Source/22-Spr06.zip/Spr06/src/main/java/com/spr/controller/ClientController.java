package com.spr.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class ClientController {
	@RequestMapping("api/client.php")
	public String client() {
		return "client";
	}
	
	@RequestMapping("api/crud.php")
	public String crud() {
		return "crud";
	}
}
