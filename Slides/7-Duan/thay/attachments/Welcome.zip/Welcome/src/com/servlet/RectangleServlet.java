package com.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/hinh-chu-nhat.php")
public class RectangleServlet extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.getRequestDispatcher("/WEB-INF/views/hinh-chu-nhat.jsp").forward(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// Lấy dữ liệu từ form
		String width = req.getParameter("rong");
		String length = req.getParameter("dai");
		// Chuyển đổi từ String sang double
		double x = Double.parseDouble(width);
		double y = Double.parseDouble(length);
		// Tính diện tích và chu vi
		double s = x*y;
		double p = (x+y)*2;
		// Truyền dữ liệu sang hinh-chu-nhat.jsp
		req.setAttribute("chu_vi", p);
		req.setAttribute("dien_tich", s);
		// Chuyển tiếp sang hinh-chu-nhat.jsp
		req.getRequestDispatcher("/WEB-INF/views/hinh-chu-nhat.jsp").forward(req, resp);
	}
}
