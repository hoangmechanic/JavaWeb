package com.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/param.aspx")
public class ParamServlet extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.getRequestDispatcher("/WEB-INF/views/form.jsp").forward(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		//String fullname = "Nguyen Nghiem";
		
		// Lấy họ tên từ form nhập
		String fullname = req.getParameter("hoten");
		
		// Truyền sang form.jsp
		req.setAttribute("myname", fullname);
		
		// Chuyển tiếp sang form.jsp
		req.getRequestDispatcher("/WEB-INF/views/form.jsp").forward(req, resp);
	}
}
