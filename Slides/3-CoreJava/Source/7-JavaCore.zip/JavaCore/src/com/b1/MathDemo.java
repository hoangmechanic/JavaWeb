package com.b1;

public class MathDemo {

	public static void main(String[] args) {
		double x = 2, y = 7;
		
		double z = Math.pow(x, y);
		System.out.printf("Math.pow(%.2f, %.2f)= %.2f\n", x, y, z);
		
		double w = Math.sqrt(y);
		System.out.printf("Math.sqrt(%.0f) = %.2f\n", y, w);
		
		double ww = Math.ceil(w);
		System.out.printf("Math.ceil(%.2f) = %.0f\n", w, ww);
		
		double r = Math.round((Math.random()*74 + 25));
		System.out.printf("Random = %.0f\n", r);
	}

}
