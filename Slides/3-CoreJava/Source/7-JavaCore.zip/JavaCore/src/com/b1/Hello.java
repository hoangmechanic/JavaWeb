package com.b1;

public class Hello {
	public static void main(String[] args) {
		System.out.println("Hello Java World!");
		myfunc();
	}

	private static void myfunc() {
		System.out.println("My Function");
	}
}
