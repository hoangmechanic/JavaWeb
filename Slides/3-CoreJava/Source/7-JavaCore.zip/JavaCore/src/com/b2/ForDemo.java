package com.b2;

import java.util.Scanner;

public class ForDemo {

	public static void main(String[] args) {
		//bangCuuChuong();
		//mang();
		tong();
	}

	private static void tong() {
		Scanner scanner = new Scanner(System.in);
		// Khai báo mảng
		int[] x = new int[5];
		
		// Nhập dữ liệu
		for(int i=0;i<x.length;i++) {
			System.out.printf(">> x[%d] = ", i);
			x[i] = scanner.nextInt();
		}
		
		// Tính tổng
		int sum = 0;
		for(int a : x) {
			sum += a;
		}
		System.out.printf("Tổng: %d", sum);
	}

	private static void mang() {
		Scanner scanner = new Scanner(System.in);
		// Khai báo mảng
		int[] x = new int[5];
		// Nhập dữ liệu
		for(int i=0;i<x.length;i++) {
			System.out.printf(">> x[%d] = ", i);
			x[i] = scanner.nextInt();
		}
		// Xuất mảng
		for(int i=0;i<x.length;i++) {
			System.out.printf("%d ", x[i]);
		}
	}

	private static void bangCuuChuong() {
		for(int x = 2; x<=9;x++) {
			for(int i=1; i<=10;i++) {
				System.out.printf("%d x %d = %d", x, i, x * i);
				System.out.println();
			}
			System.out.println("---------------------");
		}
	}

}
