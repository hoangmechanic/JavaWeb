package com.b2;

import java.util.Scanner;

public class PTB2 {
	static Scanner scanner = new Scanner(System.in);
	
	public static void main(String[] args) {
		//giaiPtb1();
		giaiPtb2();
	}

	private static void giaiPtb2() {
		double a, b, c, delta, x1, x2, x0;
		
		System.out.print("a = ");
		a = scanner.nextDouble();
		
		System.out.print("b = ");
		b = scanner.nextDouble();
		
		System.out.print("c = ");
		c = scanner.nextDouble();
		
		delta = Math.pow(b, 2) - 4 * a * c;
		
		if(delta < 0) {
			System.out.println("Vô nghiệm");
		}
		else if(delta == 0) {
			x0 = -b/(2*a);
			System.out.printf("xo=%.2f", x0);
		}
		else {
			x1 = (-b+Math.sqrt(delta))/(2*a);
			x2 = (-b-Math.sqrt(delta))/(2*a);
			System.out.printf("x1=%.2f\nx2=%.2f", x1, x2);
		}
	}

	private static void giaiPtb1() {
		double a, b, x;
		
		System.out.print("a = ");
		a = scanner.nextDouble();
		
		System.out.print("b = ");
		b = scanner.nextDouble();
		
		if(a == 0) {
			if(b == 0) {
				System.out.println("Vô số nghiệm!");
			}
			else {
				System.out.println("Vô nghiệm!");
			}
		}
		else {
			x = -b/a;
			System.out.printf("x=%.2f", x);
		}
	}

}
