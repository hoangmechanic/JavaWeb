package com.b2;

import java.util.Scanner;

public class TryCatch {

	public static void main(String[] args) {
		nhapSoNguyenDuong();

	}

	private static void nhapSoNguyenDuong() {
		Scanner scanner = new Scanner(System.in);
		while(true) {
			try {
				System.out.print("Số = ");
				int n = scanner.nextInt();
				if(n < 0) {
					System.out.println("Vui lòng nhập số dương!");
				}
				else {
					System.out.println("Số bạn vừa nhập là " + n);
					break;
				}
			} 
			catch (Exception e) {
				scanner.nextLine();
				System.out.println("Vui lòng nhập số!");
			}
		}
	}

}
