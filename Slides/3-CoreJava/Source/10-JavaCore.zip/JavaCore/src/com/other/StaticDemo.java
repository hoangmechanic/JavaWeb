package com.other;

public class StaticDemo {
	int x;
	static int y;
	
	static {
		//x += 5;
		y += 7;
	}
	
	void mx() {
		x += 5;
		y += 7;
	}
	
	static void my() {
		//x += 5;
		y += 7;
	}
}
