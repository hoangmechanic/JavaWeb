package com.other;

public class TestStatic {

	public static void main(String[] args) {
		StaticDemo.my();
		System.out.printf("%d", StaticDemo.y);
		
		StaticDemo a = new StaticDemo();
		StaticDemo b = new StaticDemo();

		a.x = 100;
		a.y = 100;
		
		b.x = 200;
		b.y = 200;
		
		StaticDemo.my();
		
		System.out.println();
		System.out.printf("%d, %d, %d, %d", a.x, a.y, b.x, b.y);
	}

}
