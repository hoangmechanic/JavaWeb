package com.oop;

import java.util.Scanner;

public class HinhChuNhat extends Hinh{
	double rong;
	double dai;
	
	public HinhChuNhat(double rong, double dai) {
		super("Chữ Nhật");
		this.rong = rong;
		this.dai = dai;
	}
	
	public HinhChuNhat() {
		super("Chữ Nhật");
	}
	
	@Override
	public void input() {
		Scanner scanner = new Scanner(System.in);
		
		System.out.println(">> Rộng: ");
		this.rong = scanner.nextDouble();
		
		System.out.println(">> Dài: ");
		this.dai = scanner.nextDouble();
	}
	
	@Override
	public double getDienTich() {
		return this.rong * this.dai;
	}
	
	@Override
	public double getChuVi() {
		return (this.rong + this.dai)*2;
	}
}
