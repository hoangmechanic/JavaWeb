package com.oop;

public abstract class Hinh {
	String ten;
	
	public Hinh(String ten) {
		this.ten = ten;
	}
	
	public abstract double getDienTich();
	
	public abstract double getChuVi() ;
	
	public void print() {
		System.out.println(this.ten);
		System.out.println(this.getDienTich());
		System.out.println(this.getChuVi());
	}
	
	public void input() {}
}
