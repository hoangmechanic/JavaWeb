package com.oop;

import java.util.Scanner;

public class QuanLyHinh {
	public static void main(String[] args) {
		//basic();
		//adv1();
		adv2();
	}

	private static void adv2() {
		Scanner scanner = new Scanner(System.in);
		
		Hinh[] dsh = new Hinh[3];
		// Nhập
		for(int i=0;i<dsh.length;i++) {
			System.out.print("Hình gì (CN=1, T=2)? ");
			int choice = scanner.nextInt();
			if(choice == 1) {
				dsh[i] = new HinhChuNhat();
				dsh[i].input();
			}
			else {
				dsh[i] = new HinhTron();
				dsh[i].input();
			}
		}
		// Xuất
		for(Hinh h : dsh) {
			h.print();
			System.out.println("-----");
		}
	}

	private static void adv1() {
		Hinh[] dsh = new Hinh[3];
		
		dsh[0] = new HinhChuNhat(10, 20);
		dsh[1] = new HinhTron(30);
		dsh[2] = new HinhChuNhat(100, 50);
		
		for(Hinh h : dsh) {
			h.print();
			System.out.println("-----");
		}
	}

	private static void basic() {
		Hinh h1 = new HinhChuNhat(10, 20);
		Hinh h2 = new HinhTron(30);
		
		h1.print();
		System.out.println("--------------");
		h2.print();
	}
}
