package com.oop;

public class XMath {
	
	static double min(double...args) {
		double min = args[0];
		for(int i=1;i<args.length;i++) {
			if(min > args[i]) {
				min = args[i];
			}
		}
		return min;
	}
	
}
