package com.inter;

public class MyClass implements MyInter {

	@Override
	public void m1() {
		// TODO Auto-generated method stub
	}

	@Override
	public int m3(String s) {
		// TODO Auto-generated method stub
		return 0;
	}
	
	@Override
	public void m2() {
		// TODO Auto-generated method stub
		MyInter.super.m2();
	}
}
