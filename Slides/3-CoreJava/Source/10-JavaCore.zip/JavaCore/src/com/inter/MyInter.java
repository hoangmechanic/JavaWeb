package com.inter;

public interface MyInter {
	void m1();
	default void m2() {}
	int m3(String s);
}