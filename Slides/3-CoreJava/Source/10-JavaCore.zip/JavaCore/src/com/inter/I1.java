package com.inter;

public interface I1 {
	void m1();
}
