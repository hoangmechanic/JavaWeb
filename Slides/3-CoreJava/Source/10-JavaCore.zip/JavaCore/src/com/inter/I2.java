package com.inter;

public interface I2 {
	void m2();
}
