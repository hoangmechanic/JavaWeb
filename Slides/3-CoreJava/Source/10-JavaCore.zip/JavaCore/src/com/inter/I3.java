package com.inter;

public interface I3 extends I1, I2{
	void m3();
}
