package com.b2;

import java.util.Scanner;

public class SwitchDemo {
	static Scanner scanner = new Scanner(System.in);
	
	public static void main(String[] args) {
		System.out.print("Month: ");
		int month = scanner.nextInt();
		
		switch (month) {
		case 2:
			System.out.print("Year: ");
			int year = scanner.nextInt();
			if(year % 4 == 0 && year % 100 != 0) {
				System.out.println(29);
			}
			else {
				System.out.println(28);
			}
			break;
		case 4:
		case 6:
		case 8:
		case 9:
			System.out.println(30);
			break;
		default:
			System.out.println(31);
			break;
		}
	}
}
