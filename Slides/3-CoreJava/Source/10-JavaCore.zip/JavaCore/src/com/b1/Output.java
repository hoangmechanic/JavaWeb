package com.b1;

public class Output {

	public static void main(String[] args) {
		System.out.print("Nhất");
		System.out.println(" Nghệ");
		
		System.out.println();
		
		String name = "Nguyễn Nghiệm";
		int age = 48;
		double salary = 1200.5678;
		System.out.printf("Tôi là %s, %d tuổi, lương %.2f USD", name, age, salary);
	}

}
