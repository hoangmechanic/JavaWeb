package com.coll;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public class MapDemo {

	public static void main(String[] args) {
		//basic();
		advance();
	}

	private static void advance() {
		Map<String, Item> map = new HashMap<>();
		
		map.put("IPH", new Item("iPhone 20", 3000));
		map.put("NOK", new Item("Nokia", 200));
		map.put("SAM", new Item("Samsung Note10", 2000));
		map.put("SON", new Item("Sony Erricson", 500));
		map.put("MOT", new Item("Motorola", 700));
		
		Item item = map.get("NOK");
		item.price = 2200;
		
		Collection<Item> values = map.values();
		double total = 0;
		for(Item itm : values) {
			total += itm.price;
			itm.print();
			System.out.println("-----------");
		}
		
		System.out.printf("Giá trung bình: %.2f", total/map.size());
	}

	private static void basic() {
		Map<String, Double> map = new TreeMap<>();
		map.put("Nghiệm", 5.0);
		map.put("Tuấn", 0.0);
		map.put("Cường", 9.9);
		map.put("Phương", 7.0);
		map.put("Hạnh", 8.0);
		map.put("Tuấn", 6.0);
		
		System.out.println(map.toString());
		System.out.println("size: "+map.size());
		System.out.println("isEmpty: "+map.isEmpty());
		System.out.println("containsKey: "+map.containsKey("Nghiệm"));
		System.out.println("keySet: "+map.keySet());
		System.out.println("values: "+map.values());
		
		Set<String> keys = map.keySet();
		for(String key : keys) {
			Double value = map.get(key);
			System.out.printf("+ %s=%.1f\n", key, value);
		}
	}

}
