package com.coll;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class CollectionDemo {

	public static void main(String[] args) {
		//basic();
		//advance();
		//utility();
		utility2();
	}

	private static void utility2() {
		List<Item> list = new ArrayList<>();
		
		list.add(new Item("iPhone 20", 3000));
		list.add(new Item("Nokia", 200));
		list.add(new Item("Samsung Note10", 2000));
		list.add(new Item("Sony Erricson", 500));
		list.add(2, new Item("Motorola", 700));
		
		Comparator<Item> tieuChi = new Comparator<Item>() {
			@Override
			public int compare(Item o1, Item o2) {
				if(o1.price > o2.price) {
					return 1;
				}
				if(o1.price < o2.price) {
					return -1;
				}
				return 0;
			}
		};
		
		Collections.sort(list, tieuChi);
		
		for(Item itm : list) {
			itm.print();
			System.out.println("-----");
		}
	}

	private static void utility() {
		List<Integer> list = new ArrayList<>();
		list.add(9);
		list.add(2);
		list.add(1);
		list.add(5);
		list.add(4);
		
		Collections.sort(list);
		System.out.println(list.toString());
		
		int i = Collections.binarySearch(list, 5);
		System.out.println("Vi tri cua 5 la " + i);
		
		Collections.swap(list, 2, 4);
		System.out.println(list.toString());
		
		Collections.reverse(list);
		System.out.println(list.toString());
		
		Collections.rotate(list, 2);
		System.out.println(list.toString());
		
		Collections.shuffle(list);
		System.out.println(list.toString());
	}

	private static void advance() {
		List<Item> list = new ArrayList<>();
		
		list.add(new Item("iPhone 20", 3000));
		list.add(new Item("Nokia", 200));
		list.add(new Item("Samsung Note10", 2000));
		list.add(new Item("Sony Erricson", 500));
		
		list.add(2, new Item("Motorola", 700));
		Item item = list.get(1);
		item.price = 2200;
		
		for(Item itm : list) {
			itm.print();
			System.out.println("-----");
		}
	}

	private static void basic() {
		Collection<Integer> coll1 = new ArrayList<>();
		List<Integer> coll2 = new ArrayList<>();
		ArrayList<Integer> coll3 = new ArrayList<>();
		
		Collection<Integer> coll4 = new HashSet<>();
		Set<Integer> coll5 = new HashSet<>();
		HashSet<Integer> coll6 = new HashSet<>();
		
		coll2.add(1);
		coll2.add(2);
		coll2.add(2);
		
		System.out.println("size: "+coll2.size());
		System.out.println("isEmpty: "+coll2.isEmpty());
		System.out.println("indexOf: "+coll2.indexOf(2));
		System.out.println("lastIndexOf: "+coll2.lastIndexOf(2));
		System.out.println("contains: "+coll2.contains(2));
		System.out.println("toString: "+coll2.toString());
		
		coll5.add(100);
		coll5.add(200);
		coll5.add(200);
		coll5.add(1);
		
		//coll5.addAll(coll2);
		//coll5.retainAll(coll2);
		coll5.removeAll(coll2);
		
		System.out.println("toString: "+coll5.toString());
	}

}
