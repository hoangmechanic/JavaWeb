package com.coll;

public class Item {
	String name;
	double price;
	
	public Item(String name, double price){
		this.name = name;
		this.price = price;
	}
	
	public double getVAT() {
		return this.price * 0.1;
	}
	
	public void print() {
		System.out.println(">>Name: " + this.name);
		System.out.println(">>Price: " + this.price);
		System.out.println(">>VAT: " + this.getVAT());
	}
}
