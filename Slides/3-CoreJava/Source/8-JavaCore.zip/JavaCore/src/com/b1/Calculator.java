package com.b1;

import java.util.Scanner;

/**
 * Lớp này minh họa tổ chức một chương trình trong Java
 * @version 1.0
 * @author Nguyễn Nghiệm
 */
public class Calculator {
	static Scanner scanner  = new Scanner(System.in);
	
	public static void main(String[] args) {
		menu();
	}

	/**
	 * Hiển thị menu
	 * @author Nguyễn Nghiệm
	 */
	private static void menu() {
		System.out.println("MÁY TÍNH CÁ NHÂN");
		System.out.println("1. Cộng");
		System.out.println("2. Trừ");
		System.out.println("3. Kết thúc");
		System.out.print(">> Chọn chức năng: ");
		
		int choice = scanner.nextInt();
		/*
		 * Dựa vào giá trị của choice 
		 * để thực hiện công việc mong muôn
		 */
		if(choice == 3) {
			System.exit(0);
		}
		else if(choice == 1) { // cộng
			add();
		}
		else if(choice == 2) {
			sub();
		}
		else {
			System.out.println("Vui lòng chọn 1, 2 hoặc 3!");
		}
	}

	private static void sub() {	
		System.out.print(">> a = ");
		double a = scanner.nextDouble();
		
		System.out.print(">> b = ");
		double b = scanner.nextDouble();
		
		double c = a - b;
		
		System.out.printf(">>>Hiệu của %.2f và %.2f là %.2f", a, b, c);
	}

	private static void add() {
		System.out.print(">> a = ");
		double a = scanner.nextDouble();
		
		System.out.print(">> b = ");
		double b = scanner.nextDouble();
		
		double c = a + b;
		
		System.out.printf(">>>Tổng của %.2f và %.2f là %.2f", a, b, c);
	}
}
