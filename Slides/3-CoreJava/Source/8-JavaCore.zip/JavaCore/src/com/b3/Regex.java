package com.b3;

import java.util.Scanner;

public class Regex {
	static Scanner scanner = new Scanner(System.in);
	
	public static void main(String[] args) {
		//basic();
		validate();
	}

	private static void validate() {
		System.out.print(">>Id: "); // 5 ký tự hoa
		String id = scanner.nextLine();
		
		System.out.print(">>Email: "); // email
		String email = scanner.nextLine();
		
		System.out.print(">>Mobile: "); // mobile VN
		String mobile = scanner.nextLine();
		
		System.out.print(">>Moto Number: "); // Sai gon
		String moto = scanner.nextLine();
		
		System.out.print(">>Description: "); // Nhiều nhất 20 ký tự
		String desc = scanner.nextLine();
		
		StringBuffer errors = new StringBuffer();
		
		if(!id.matches("[A-Z]{5}")) {
			errors.append("\n\t+ Invalid id!");
		}
		if(!email.matches("\\w+@\\w+(\\.\\w+){1,2}")) {
			errors.append("\n\t+ Invalid email!");
		}
		if(!mobile.matches("0\\d{9,10}")) {
			errors.append("\n\t+ Invalid mobile number!");
		}
		if(!moto.matches("5\\d-[A-Z]\\d-((\\d{4})|(\\d{3}\\.\\d{2}))")) {
			errors.append("\n\t+ Invalid moto number!");
		}
		if(!desc.matches(".{0,20}")) {
			errors.append("\n\t+ Invalid description!");
		}
		
		if(errors.length() == 0) {
			System.out.println("Chúc mừng, bạn đã nhập đúng!");
		}
		else {
			System.out.println("Vui lòng sửa các lỗi sau: " + errors);
		}
	}

	private static void basic() {
		String s = "ABCD";
		
		System.out.println(s.matches("[0-9]+"));
		System.out.println(s.matches("[A-Z]+"));
		System.out.println(s.matches("[A-Z]{2,3}"));
		System.out.println(s.matches("[A-Z]"));
	}

}
