package com.b2;

import java.util.Scanner;

public class WhileDemo {
	public static void main(String[] args) {
		//demo1();
		//demo2();
		//demo3();
		//demo4();
		game();
	}

	private static void game() {
		int count = 0, n = (int)Math.round(20*Math.random());
		
		Scanner scanner = new Scanner(System.in);
		while(true) {
			System.out.print(">> Số của bạn? ");
			int nn = scanner.nextInt();
			count++;
			if(n > nn) {
				System.out.println(">> Số của bạn NHỎ hơn số bí mật!");
			}
			else if(n < nn) {
				System.out.println(">> Số của bạn LỚN hơn số bí mật!");
			}
			else {
				System.out.println(">> Chúc mừng bạn đã đoán đúng!");
				System.out.printf(">> Số lần đoán %d", count);
				break;
			}
		}
	}

	private static void demo4() {
		int n = 987654321;
		int i = 2;
		while(i < n/2) {
			if(n % i == 0) {
				System.out.println(i);
			}
			i++;
		}
	}

	private static void demo3() {
		int n = 987654321;
		int m = 0;
		while(n > 0) {
			int x = n % 10;
			m = m*10 + x;
			n /= 10;
		}
		System.out.println(m);
	}

	private static void demo2() {
		int n = 987654321;
		while(n > 0) {
			int x = n % 10;
			System.out.println(x);
			n /= 10;
		}
	}

	private static void demo1() {
		int i = 0;
		while(i < 10) {
			System.out.println(Math.pow(i, 3));
			i++;
		}
	}
}
