package com.b1;

import java.util.Scanner;

public class Input {
	public static void main(String[] args) {
		System.out.println("THÔNG TIN SINH VIÊN");
		System.out.println("----------------------------");
		
		Scanner scanner = new Scanner(System.in);
		
		System.out.print("+ Điểm trung bình: ");
		double mark = scanner.nextDouble();
		scanner.nextLine();// thải ký tự Enter
		
		System.out.print("+ Họ và tên: ");
		String name = scanner.nextLine();
		
		System.out.println("KẾT QUẢ:");
		System.out.printf(">> %s có điểm trung bình là %.2f", name, mark);
	}
}
