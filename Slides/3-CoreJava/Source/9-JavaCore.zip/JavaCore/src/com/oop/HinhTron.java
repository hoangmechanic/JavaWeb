package com.oop;

import java.util.Scanner;

public class HinhTron extends Hinh{
	double banKinh;
	
	public HinhTron(double banKinh) {
		super("Tr�n");
		this.banKinh = banKinh;
	}
	
	public HinhTron() {
		super("Tr�n");
	}
	
	@Override
	public void input() {
		Scanner scanner = new Scanner(System.in);
		
		System.out.println(">> B�n k�nh: ");
		this.banKinh = scanner.nextDouble();
	}
	
	@Override
	public double getDienTich() {
		return Math.PI * Math.pow(this.banKinh, 2);
	}
	
	@Override
	public double getChuVi() {
		return 2 * Math.PI * this.banKinh;
	}
}
