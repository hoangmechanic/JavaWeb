package com.oop;

public class HinhTamGiac extends Hinh{

	public HinhTamGiac() {
		super("Tam gi�c");
	}

	@Override
	public double getDienTich() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double getChuVi() {
		// TODO Auto-generated method stub
		return 0;
	}

}
