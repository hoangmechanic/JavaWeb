package com.oop;

public class TestXMath {

	public static void main(String[] args) {
		double min = XMath.min(4, 8, 1, 9, 4, 2);
		System.out.println(min);
	}

}
