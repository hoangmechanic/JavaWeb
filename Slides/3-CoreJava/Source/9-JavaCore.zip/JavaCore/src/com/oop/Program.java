package com.oop;

import java.util.Scanner;

public class Program {
	static Scanner scanner = new Scanner(System.in);
	public static void main(String[] args) {
		//basic();
		advance();
	}

	private static void advance() {
		Student[] dssv = new Student[5];
		
		for(int i=0;i<dssv.length;i++) {
			System.out.print(">> Họ và tên: ");
			String hoten = scanner.nextLine();
			
			System.out.print(">> Điểm: ");
			double diem = scanner.nextDouble();
			scanner.nextLine();
			
			dssv[i] = new Student(hoten, diem);
		}
		
		for(Student sv: dssv) {
			System.out.printf(">> %s, %.2f, %s\n", 
					sv.fullname, sv.mark, sv.getGrade());
		}
	}

	private static void basic() {
		Student sv = new Student("Nguyễn Nghiệm", 8);
		String xepLoai = sv.getGrade();
		System.out.println(xepLoai);
	}

}
