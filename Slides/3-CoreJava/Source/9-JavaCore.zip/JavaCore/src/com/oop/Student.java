package com.oop;

public class Student {
	String fullname;
	double mark;
	
	public Student(String hoten, double diem) {
		this.fullname = hoten;
		this.mark = diem;
	}
	
	public String getGrade() {
		if(mark < 5) {
			return "Yếu/Kém";
		}
		if(mark > 8) {
			return "Giỏi/Xuất sắc";
		}
		return "Trung bình/Khá";
	}
}
