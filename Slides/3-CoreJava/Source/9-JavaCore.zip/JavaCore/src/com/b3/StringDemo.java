package com.b3;

public class StringDemo {

	public static void main(String[] args) {
		//basic();
		//xuLyHoTen();
		//tachChuoi();
		//hamTienIch();
		buffer();
	}

	private static void buffer() {
		StringBuffer buffer = new StringBuffer();
		
		buffer.append("Nghiệm");
		buffer.insert(0, " ");
		buffer.insert(0, "Nguyễn");
		System.out.println(buffer);
		
		buffer.setCharAt(3, 'M');
		System.out.println(buffer);
		
		buffer.delete(3, 7);
		System.out.println(buffer);
	}

	private static void hamTienIch() {
		String name = "Nguyễn Nghiệm";
		int age = 48;
		String s = String.format("I'm %s, %d years old", name, age);
		
		String[] names = {
				"Phạm Văn Tuấn", 
				"Nguyễn Văn Tèo", 
				"Trần Mỹ Linh", 
				"Lê Tuấn Nghĩa", 
				"Đoàn Văn Quan"
		};
		String ss = String.join("~", names);
		
		System.out.println(s);
		System.out.println(ss);
	}

	private static void tachChuoi() {
		String s = "7, 8; 2,         4, 5, 6";
		String[] ss = s.replaceAll(";", ",").split(",");
		for(String x : ss) {
			int a = Integer.parseInt(x.trim());
			if(a % 2 == 0) {
				System.out.println(a);
			}
		}
	}

	private static void xuLyHoTen() {
		String[] names = {
				"Phạm Văn Tuấn", 
				"Nguyễn Văn Tèo", 
				"Trần Mỹ Linh", 
				"Lê Tuấn Nghĩa", 
				"Đoàn Văn Quan"
		};
		System.out.println("NHỮNG NGƯỜI TÊN TUẤN HOẶC HỌ NGUYỄN:");
		for(String name : names) {
			String s = name.toUpperCase();
			if(s.startsWith("NGUYỄN ") || s.endsWith(" TUẤN")) {
				System.out.println(">> " + s);
			}
		}
		System.out.println("NHỮNG NGƯỜI CÓ TÊN LÓT LÀ MỸ:");
		for(String name : names) {
			if(name.toUpperCase().contains(" MỸ ")) {
				int i = name.lastIndexOf(" ");
				String lastname = name.substring(i).trim();
				System.out.println(">> " + lastname);
			}
		}
	}

	private static void basic() {
		String s1 = "Hello World";
		String s2 = new String("Hello World");
		
		System.out.printf("\n\t+s1.length()=%d", s1.length());
		System.out.printf("\n\t+s1.toUpperCase(): %s", s1.toUpperCase());
		System.out.printf("\n\t+s1.contains(\"Hello\"): %b", s1.contains("Hello"));
		System.out.printf("\n\t+s1.endsWith(\"Hello\"): %b", s1.endsWith("Hello"));
		System.out.printf("\n\t+s1.indexOf(\"World\"): %d", s1.indexOf("World"));
		System.out.printf("\n\t+s1.substring(0, 4): %s", s1.substring(0, 4));
		System.out.printf("\n\t+s1.substring(4): %s", s1.substring(4));
		
		System.out.printf("\n\t+s1==s2: %b", s1 == s2);
		System.out.printf("\n\t+s1.equals(s2): %b", s1.equals(s2));
	}

}
