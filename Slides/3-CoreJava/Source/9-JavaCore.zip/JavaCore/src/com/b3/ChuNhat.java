package com.b3;

public class ChuNhat {
	double rong;
	double dai;
	
	public ChuNhat(double rong, double dai){
		this.rong = rong;
		this.dai = dai;
	}
	
	public ChuNhat(double x1, double y1, double x2, double y2){
		this.rong = Math.abs(x2-x1);
		this.dai = Math.abs(y2-y1);
	}
	
	double getDienTich() {
		return this.rong * this.dai;
	}
	
	double getChuVi() {
		return (this.rong + this.dai)*2;
	}
}
