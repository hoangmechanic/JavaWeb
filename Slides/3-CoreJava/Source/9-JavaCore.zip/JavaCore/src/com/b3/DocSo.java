package com.b3;

public class DocSo {
	static String[] words = {"không", "một", "hai", "ba", "bốn", "năm", "sáu", "bảy", "tám", "chín"};
	static String[] units = {"", "ngàn", "triệu", "tỷ"};
	
	public static void main(String[] args) {
		int n = 1234567891;
		int m = n/1000;
		int l = m/1000;
		int p = l/1000;
		read(p);
		System.out.print(" tỷ");
		read(l);
		System.out.print(" triệu");
		read(m);
		System.out.print(" ngàn");
		read(n);
	}

	private static void read(int n) {
		int x = (n / 100) % 10; // chu so hang tram
		int y = (n / 10) % 10; // chu so hang chuc
		int z = (n / 1) % 10; // chu so hang don vi
		int a = n / 1000; // so con lai
		
		if(n == 0) {
			System.out.println("không");
		}
		else if(x != 0 || y != 0 || z != 0) {
			// Hàng trăm
			if(a > 0 || x != 0) {
				System.out.printf(" %s trăm", words[x]);
			}
			// Hàng chục
			if(y == 1) {
				System.out.printf(" mười");
			}
			else if(y == 0 && (x + a > 0) && z != 0) {
				System.out.printf(" linh");
			}
			else if(y != 0){
				System.out.printf(" %s mươi", words[y]);
			}
			// Hàng đơn vị
			if(z == 1 && y > 1) {
				System.out.printf(" mốt");
			}
			else if(z == 5 && y > 0) {
				System.out.printf(" lăm");
			}
			else if(z != 0) {
				System.out.printf(" %s", words[z]);
			}
		}
	}

}
