package com.b3;

public class Test {
	public static void main(String[] args) {
		chuNhat();
	}

	private static void chuNhat() {
		ChuNhat h1 = new ChuNhat(10, 15);
		ChuNhat h2 = new ChuNhat(5, 5, 30, 25);

		System.out.printf("S=%f, P=%f\n", h1.getDienTich(), h1.getChuVi());
		System.out.printf("S=%f, P=%f\n", h2.getDienTich(), h2.getChuVi());
	}
}
