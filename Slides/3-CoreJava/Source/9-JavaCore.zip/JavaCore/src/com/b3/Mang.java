package com.b3;

import java.util.Arrays;

public class Mang {

	public static void main(String[] args) {
		//basic();
		//min();
		//sort();
		advance();
	}

	private static void advance() {
		double[] a = {3, 9, 12, 1, 7, 5};
		
		System.out.println(Arrays.toString(a));
		
		Arrays.sort(a);
		System.out.println(Arrays.toString(a));
		
		int i = Arrays.binarySearch(a, 5);
		System.out.printf("i = %d, a[%d] = %.0f\n", i, i, a[i]);
		
		Arrays.fill(a, 2019);
		System.out.println(Arrays.toString(a));
	}

	private static void sort() {
		int x, a[] = {8, 5, 3, 4, 2};
		
		for(int i=0;i<a.length-1;i++) {
			for(int j=i+1;j<a.length;j++) {
				if(a[j] < a[i]) {
					x = a[j];
					a[j] = a[i];
					a[i] = x;
				}
			}
		}
		
		for(int y : a) {
			System.out.printf("%d ", y);
		}
	}

	private static void min() {
		int[] a = {8, 5, 3, 4, 2};
		int min = a[0];
		for(int i=1; i<a.length;i++) {
			if(a[i] < min) {
				min = a[i];
			}
		}
		System.out.println("Min = " + min);
	}

	private static void basic() {
		int[] a = {8, 9, 3, 4, 2};
		int[] b = new int[a.length];
		
		for(int i=0;i<a.length;i++) {
			b[i] = (int) Math.pow(a[i], 3);
		}
		
		for(int x : b) {
			System.out.printf(">>%d\n", x);
		}
		
		System.out.printf("b[%d]=%d, b.length=%d", 2, b[2], b.length);
	}

}
