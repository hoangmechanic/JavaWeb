package com.b1;

public class NumberProgram {

	public static void main(String[] args) {
		int n = 123;
		
		int dv = n % 10;
		int chuc = (n/10)%10;
		int tram = n/100;
		
		//Xuất các chữ số hàng đơn vị và hàng trăm
		System.out.printf("Đơn vị %d, trăm %d", dv, tram);
		
		System.out.println();
		
		//Xuất tổng các chữ số
		int sum = dv + chuc + tram;
		System.out.printf("%d + %d + %d = %d", tram, chuc, dv, sum);
	}

}
