package com.kyvong.demo;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.kyvong.util.JPAUtil;

public class Demo00_Structure {
	public static void main(String[] args) {
	}

	private static void structure1() {
		// Create EntityManagerFactory from persistence.xml
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("WebAppPU");
		// Create EntityManager for programming
		EntityManager em = factory.createEntityManager();

		// TODO: Database programming codes here

		// Finish working with db
		factory.close();
	}
	
	private static void structure2() {
		// Create EntityManager for programming
		EntityManager em = JPAUtil.createEntityManager();

		// TODO: Database programming codes here

		// Finish working with db
		JPAUtil.shutdown();
	}
}
