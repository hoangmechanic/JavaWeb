package com.kyvong.demo;

import javax.persistence.EntityManager;

import com.kyvong.entity.Category;
import com.kyvong.util.JPAUtil;

public class Demo07_JPAUtil {
	public static void main(String[] args) {
	}
	
	private static void codeStructure() {
		EntityManager em = JPAUtil.createEntityManager();

		// TODO: Database programming codes here
		Category entity = em.find(Category.class, 1005);
		
		// Finish working with db
		JPAUtil.shutdown();
	}
}
