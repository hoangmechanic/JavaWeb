package com.kyvong.dao;

import java.util.List;

import com.kyvong.entity.Customer;

public class CustomerDAO extends SuperDAO<Customer, String>{
	public List<Customer> findByRole(boolean admin){
		String jpql = "SELECT o FROM Customer o WHERE o.admin=?0";
		return this.findEntities(jpql, 0, 0, admin);
	}
}
