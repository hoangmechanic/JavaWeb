package com.kyvong.demo;

import java.util.List;

import javax.persistence.EntityManager;

import com.kyvong.entity.Category;
import com.kyvong.entity.Product;
import com.kyvong.util.JPAUtil;

public class Demo04_QueryAssociatedEntities {
	public static void main(String[] args) {
		//oneToMany();
		manyToOne();
	}
	
	private static void manyToOne() {
		EntityManager em = JPAUtil.createEntityManager();
		
		// 1. One Product
		Product product = em.find(Product.class, 1005);
		// 2. One Category
		Category category = product.getCategory();
		
		System.out.println(category.getName());
		
		JPAUtil.shutdown();
	}

	private static void oneToMany() {
		EntityManager em = JPAUtil.createEntityManager();

		// 1. One Category
		Category category = em.find(Category.class, 1005);
		// 2. Many Products
		List<Product> products = category.getProducts();
		
		products.forEach(p->{
			System.out.println(p.getName());
		});
		
		JPAUtil.shutdown();
	}
}
