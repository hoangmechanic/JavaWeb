package com.kyvong.demo;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import com.kyvong.entity.Category;
import com.kyvong.util.JPAUtil;

public class Demo08_CategoryDAO {
	private EntityManager em = JPAUtil.createEntityManager();
	
	public Category findById(Integer id) {
		return em.find(Category.class, id);
	}
	public List<Category> findAll() {
		String jpql = "SELECT o FROM Category o";
		return findEntities(jpql, 0, 0);
	}
	public void create(Category entity) {
		try {
			em.persist(entity);
			em.getTransaction().commit();
		} 
		catch (Exception e) {
			em.getTransaction().rollback();
			throw new RuntimeException(e);
		}
	}
	public void update(Category entity) {
		try {
			em.merge(entity);
			em.getTransaction().commit();
		} 
		catch (Exception e) {
			em.getTransaction().rollback();
			throw new RuntimeException(e);
		}
	}
	public void remove(Integer id) {
		try {
			em.remove(this.findById(id));
			em.getTransaction().commit();
		} 
		catch (Exception e) {
			em.getTransaction().rollback();
			throw new RuntimeException(e);
		}
	}
	private List<Category> findEntities(String jpql, int pageNo, int pageSize, Object... args) {
		TypedQuery<Category> query = em.createQuery(jpql, Category.class);
		if (pageSize > 0) {
			query.setFirstResult(pageNo * pageSize);
			query.setMaxResults(pageSize);
		}
		for (int i = 0; i < args.length; i++) {
			query.setParameter(i, args[i]);
		}
		return query.getResultList();
	}

	@Override
	protected void finalize() throws Throwable {
		em.close();
		super.finalize();
	}
}
