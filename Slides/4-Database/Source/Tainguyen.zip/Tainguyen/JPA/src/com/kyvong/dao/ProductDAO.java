package com.kyvong.dao;

import java.util.List;

import com.kyvong.entity.Product;

public class ProductDAO extends SuperDAO<Product, Integer>{
	public List<Product> findByPage(int pageNo){
		String jpql = "SELECT o FROM Product o";
		return this.findEntities(jpql, pageNo, 8);
	}
	
	public List<Product> findByKeywords(String keywords){
		String jpql = "SELECT o FROM Product o "
				+ " WHERE o.name LIKE ?0 OR o.category.name LIKE ?0 OR o.category.nameVN LIKE ?0";
		return this.findEntities(jpql, 0, 0, "%"+keywords+"%");
	}
	
	
	public List<Product> findBySpecials(int special){
		String jpql = "SELECT o FROM Product o";
		switch(special) {
		case Specials.BEST:
			jpql = "SELECT o FROM Product o ORDER BY size(o.orderDetails) DESC";
			return this.findEntities(jpql, 0, 12);
		case Specials.LATEST:
			jpql = "SELECT o FROM Product o ORDER BY o.productDate DESC";
			return this.findEntities(jpql, 0, 12);
		case Specials.VIEW_COUNT:
			jpql = "SELECT o FROM Product o WHERE o.viewCount > 0 ORDER BY o.viewCount DESC";
			return this.findEntities(jpql, 0, 12);
		case Specials.DISCOUNT:
			jpql = "SELECT o FROM Product o WHERE o.discount > 0 ORDER BY o.discount DESC";
			return this.findEntities(jpql, 0, 12);
		case Specials.SPECIAL:
			jpql = "SELECT o FROM Product o WHERE o.special";
			return this.findEntities(jpql, 0, 0);
		}
		
		return this.findEntities(jpql, 0, 0);
	}
	
	static class Specials{
		static final int BEST = 0;
		static final int LATEST = 1;
		static final int VIEW_COUNT = 2;
		static final int DISCOUNT = 3;
		static final int SPECIAL = 4;
	}
}
