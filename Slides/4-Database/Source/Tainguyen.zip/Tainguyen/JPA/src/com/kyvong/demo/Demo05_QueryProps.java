package com.kyvong.demo;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.kyvong.util.JPAUtil;

public class Demo05_QueryProps {
	public static void main(String[] args) {
		//findSomeProps1();
		//findSomeProps2();
	}
	
	private static void structure() {
		EntityManager em = JPAUtil.createEntityManager();

		String jpql = "SELECT o.prop1, o.prop2,... FROM Entity o...";
		TypedQuery<Object[]> query = em.createQuery(jpql, Object[].class);
		List<Object[]> list = query.getResultList();
		
		JPAUtil.shutdown();
	}
	
	private static void findSomeProps1() {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("WebAppPU");
		EntityManager em = factory.createEntityManager();

		String jpql = "SELECT o.name, o.unitPrice FROM Product o";
		TypedQuery<Object[]> query = em.createQuery(jpql, Object[].class);
		List<Object[]> list = query.getResultList();

		list.forEach(a -> {
			System.out.println(a[0]);
		});

		JPAUtil.shutdown();
	}
	
	private static void findSomeProps2() {
		EntityManager em = JPAUtil.createEntityManager();

		String jpql = "SELECT o.category.name, sum(o.unitPrice), avg(o.unitPrice) "
				+ " FROM Product o "
				+ " GROUP BY o.category.name";
		TypedQuery<Object[]> query = em.createQuery(jpql, Object[].class);
		List<Object[]> list = query.getResultList();

		list.forEach(a -> {
			System.out.println(a[0]);
		});

		JPAUtil.shutdown();
	}
}
