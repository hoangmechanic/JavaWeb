package com.kyvong.demo;

import javax.persistence.EntityManager;

import com.kyvong.entity.Category;
import com.kyvong.util.JPAUtil;

public class Demo01_FindOne {
	public static void main(String[] args) {
		find();
		refresh();
	}
	
	private static void findStructure() {
		EntityManager em = JPAUtil.createEntityManager();

		// 1. Load & create an entity
		// Entity entity = em.find(Entity.class, primaryKey);
		
		// 2. Load props of entity
		// Entity entity = new Entity();
		// entity.setId(primaryKey)
		// em.refresh(entity);
		
		JPAUtil.shutdown();
	}
	
	private static void find() {
		EntityManager em = JPAUtil.createEntityManager();
		
		// Create entity and load data from db
		Category entity = em.find(Category.class, 1005);

		System.out.println(entity.getName());

		JPAUtil.shutdown();
	}
	
	private static void refresh() {
		EntityManager em = JPAUtil.createEntityManager();

		// Create entity
		Category entity = new Category();
		entity.setId(1005);
		// Load data from db
		em.refresh(entity);

		System.out.println(entity.getName());

		JPAUtil.shutdown();
	}
}
