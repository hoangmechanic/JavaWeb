package com.kyvong.demo;

import javax.persistence.EntityManager;

import com.kyvong.entity.Category;
import com.kyvong.util.JPAUtil;

public class Demo02_Manipulate {
	public static void main(String[] args) {
		insert();
		update();
		delete();
	}
	
	private static void manupulateStructure() {
		EntityManager em = JPAUtil.createEntityManager();

		try {
			// em.persist(entity);
			// em.merge(entity);
			// em.remove(entity);
			
			// Accept all commands executed
			em.getTransaction().commit();
		} 
		catch (Exception e) {
			// Cancel all commands executed before
			em.getTransaction().rollback();
		}

		JPAUtil.shutdown();
	}

	private static void insert() {
		EntityManager em = JPAUtil.createEntityManager();

		Category entity = new Category();
		entity.setName("Table");
		try {
			em.persist(entity);
			em.getTransaction().commit();

			System.out.println(entity.getId());
		} 
		catch (Exception e) {
			em.getTransaction().rollback();
		}

		JPAUtil.shutdown();
	}

	private static void update() {
		EntityManager em = JPAUtil.createEntityManager();

		Category entity = em.find(Category.class, 1005);
		entity.setName("Phần mềm");
		try {
			em.merge(entity);
			em.getTransaction().commit();
		} 
		catch (Exception e) {
			em.getTransaction().rollback();
		}

		JPAUtil.shutdown();
	}

	private static void delete() {
		EntityManager em = JPAUtil.createEntityManager();

		Category entity = em.find(Category.class, 1005);
		try {
			em.remove(entity);
			em.getTransaction().commit();
		} 
		catch (Exception e) {
			em.getTransaction().rollback();
		}

		JPAUtil.shutdown();
	}
}
