package com.kyvong.demo;

import java.lang.reflect.Type;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import com.kyvong.entity.Category;
import com.kyvong.util.JPAUtil;

public class Demo06_QuerySingleValue {
	public static void main(String[] args) {
		findSingleValue1();
		findSingleValue2();
		findSingleValue3();
	}
	
	private static void structure() {
		EntityManager em = JPAUtil.createEntityManager();

		String jpql = "JPQL query one value";
		TypedQuery<Type> query = em.createQuery(jpql, Type.class);
		Type object = query.getSingleResult();
		
		JPAUtil.shutdown();
	}
	
	private static void findSingleValue1() {
		EntityManager em = JPAUtil.createEntityManager();

		String jpql = "SELECT count(o) FROM Product o";
		TypedQuery<Long> query = em.createQuery(jpql, Long.class);
		Long count = query.getSingleResult();

		System.out.println(count);

		JPAUtil.shutdown();
	}
	
	private static void findSingleValue2() {
		EntityManager em = JPAUtil.createEntityManager();

		String jpql = "SELECT o.category FROM Product o WHERE o.id=1006";
		TypedQuery<Category> query = em.createQuery(jpql, Category.class);
		Category c = query.getSingleResult();

		System.out.println(c.getName());

		JPAUtil.shutdown();
	}
	
	private static void findSingleValue3() {
		EntityManager em = JPAUtil.createEntityManager();

		String jpql = "SELECT o.name, o.unitPrice FROM Product o WHERE o.id=1006";
		TypedQuery<Object[]> query = em.createQuery(jpql, Object[].class);
		Object[] a = query.getSingleResult();

		System.out.println(a[0]);

		JPAUtil.shutdown();
	}
}
