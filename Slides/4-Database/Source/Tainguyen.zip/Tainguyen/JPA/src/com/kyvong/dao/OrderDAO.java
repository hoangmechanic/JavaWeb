package com.kyvong.dao;

import java.util.Date;
import java.util.List;

import com.kyvong.entity.Order;

public class OrderDAO extends SuperDAO<Order, Integer>{
	public List<Order> findByTime(Date from, Date to){
		String jpql = "SELECT o FROM Order o WHERE o.orderDate BETWEEN ?0 AND ?1";
		return this.findEntities(jpql, 0, 0, from, to);
	}
}
