package com.kyvong.dao;

import java.lang.reflect.ParameterizedType;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import com.kyvong.util.JPAUtil;

/**
 * Lớp này cung cấp các hành động thao tác và truy vấn thực thể cơ bản nhất cần phải có.
 * Đây là lớp trừu tượng, tổng quát. Các lớp DAO cụ thể cần phải kế thừa và chỉ ra lớp thực 
 * thể và kiểu khóa chính.
 * (Ví dụ: <code>public class CategoryDAO extends SuperDAO<<b>Category</b>, <b>Integer</b>>{...}</code>) 
 * sau đó bổ sung thêm các hoạt động thao tác đặc thù của thực thể nếu cần.
 * @author Nguyễn Nghiệm
 * @version 1.0
 * @since 5/2019
 */
public abstract class SuperDAO<E, K> {
	/**
	 * EntityManager cần thiết cho các hoạt động truy vấn và thao tác
	 */
	protected EntityManager em = JPAUtil.createEntityManager();
	/**
	 * Truy vấn một thực thể theo khóa chính
	 * @param id là khóa chính
	 * @return Là thực thể tìm được hoặc null nếu không tồn tại
	 */
	public E findById(K id) {
		return em.find(getEClass(), id);
	}
	/**
	 * Truy vấn tất cả các thực thể
	 * @return Là danh sách tất cả các thực thể
	 */
	public List<E> findAll() {
		String jpql = "SELECT o FROM ? o".replace("?", getEClass().getSimpleName());
		return findEntities(jpql, 0, 0);
	}
	/**
	 * Truy vấn có phân trang các thực thể theo câu lệnh JPQL có tham số
	 * @param jpql là câu lệnh JPQL có chứa các tham số
	 * @param pageNo là trang số cần truy vấn
	 * @param pageSize là kích thước trang
	 * @param args là các giá trị tương ứng với các tham số trong @jpql
	 * @return Là danh sách thực thể tìm được
	 */
	protected List<E> findEntities(String jpql, int pageNo, int pageSize, Object... args) {
		TypedQuery<E> query = em.createQuery(jpql, getEClass());
		if (pageSize > 0) {
			query.setFirstResult(pageNo * pageSize);
			query.setMaxResults(pageSize);
		}
		for (int i = 0; i < args.length; i++) {
			query.setParameter(i, args[i]);
		}
		return query.getResultList();
	}
	/**
	 * Tạo thực thể mới
	 * @param entity là thực thể mới cần tạo
	 */
	public void create(E entity) {
		try {
			em.persist(entity);
			em.getTransaction().commit();
		} 
		catch (Exception e) {
			em.getTransaction().rollback();
			throw new RuntimeException(e);
		}
	}
	/**
	 * Cập nhật thực thể
	 * @param entity là thực thể cần cập nhật
	 */
	public void update(E entity) {
		try {
			em.merge(entity);
			em.getTransaction().commit();
		} 
		catch (Exception e) {
			em.getTransaction().rollback();
			throw new RuntimeException(e);
		}
	}
	/**
	 * Xóa các thực thể
	 * @param id là các khóa chính của các thực thể cần xóa
	 */
	@SuppressWarnings("unchecked")
	public void remove(K...ids) {
		try {
			for(K id : ids) {
				em.remove(this.findById(id));
			}
			em.getTransaction().commit();
		} 
		catch (Exception e) {
			em.getTransaction().rollback();
			throw new RuntimeException(e);
		}
	}
	/**
	 * Đóng EntityManager trước khi DAO bị giải phóng khỏi bộ nhớ
	 */
	@Override
	protected void finalize() throws Throwable {
		em.close();
		super.finalize();
	}
	/**
	 * Lấy kiểu của tham số tổng quát đầu tiên của lớp cha (đó là kiểu của E)
	 */
	@SuppressWarnings("unchecked")
	private Class<E> getEClass() {
		ParameterizedType type = (ParameterizedType) getClass().getGenericSuperclass();
		return (Class<E>) type.getActualTypeArguments()[0];
	}
}
