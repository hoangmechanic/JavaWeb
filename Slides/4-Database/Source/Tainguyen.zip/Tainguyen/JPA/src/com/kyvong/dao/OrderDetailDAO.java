package com.kyvong.dao;

import com.kyvong.entity.Order;

public class OrderDetailDAO extends SuperDAO<Order, Integer>{
	
}
