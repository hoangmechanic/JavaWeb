package com.kyvong.demo;

import java.lang.reflect.ParameterizedType;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import com.kyvong.util.JPAUtil;

public abstract class Demo09_SuperDAO<E, K> {
	protected EntityManager em = JPAUtil.createEntityManager();

	public E findById(K id) {
		return em.find(getEClass(), id);
	}

	public List<E> findAll() {
		String jpql = "SELECT o FROM ? o".replace("?", getEClass().getSimpleName());
		return findEntities(jpql, 0, 0);
	}

	protected List<E> findEntities(String jpql, int pageNo, int pageSize, Object... args) {
		TypedQuery<E> query = em.createQuery(jpql, getEClass());
		if (pageSize > 0) {
			query.setFirstResult(pageNo * pageSize);
			query.setMaxResults(pageSize);
		}
		for (int i = 0; i < args.length; i++) {
			query.setParameter(i, args[i]);
		}
		return query.getResultList();
	}

	public void create(E entity) {
		try {
			em.persist(entity);
			em.getTransaction().commit();
		} 
		catch (Exception e) {
			em.getTransaction().rollback();
			throw new RuntimeException(e);
		}
	}

	public void update(E entity) {
		try {
			em.merge(entity);
			em.getTransaction().commit();
		} 
		catch (Exception e) {
			em.getTransaction().rollback();
			throw new RuntimeException(e);
		}
	}

	public void remove(K id) {
		try {
			em.remove(this.findById(id));
			em.getTransaction().commit();
		} 
		catch (Exception e) {
			em.getTransaction().rollback();
			throw new RuntimeException(e);
		}
	}

	@Override
	protected void finalize() throws Throwable {
		em.close();
		super.finalize();
	}
	
	@SuppressWarnings("unchecked")
	private Class<E> getEClass() {
		ParameterizedType type = (ParameterizedType) getClass().getGenericSuperclass();
		return (Class<E>) type.getActualTypeArguments()[0];
	}
}