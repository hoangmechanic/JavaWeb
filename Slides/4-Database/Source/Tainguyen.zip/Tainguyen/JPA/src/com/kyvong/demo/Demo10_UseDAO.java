package com.kyvong.demo;

import java.util.List;

import com.kyvong.dao.CategoryDAO;
import com.kyvong.entity.Category;

public class Demo10_UseDAO {
	public static void main(String[] args) {
		CategoryDAO dao = new CategoryDAO();
		
		Category entity1 = new Category();
		entity1.setName("Category Name");
		entity1.setNameVN("Tên Loại");
		dao.create(entity1);
		
		Category entity2 = dao.findById(1005);
		entity2.setName("New Name");
		dao.update(entity2);
		
		dao.remove(1011, 1012, 1013);
		
		List<Category> list = dao.findAll();
		list.forEach(c->{
			System.out.println(c.getNameVN());
		});
	}
}
