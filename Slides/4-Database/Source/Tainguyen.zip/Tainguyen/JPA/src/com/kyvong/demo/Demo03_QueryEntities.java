package com.kyvong.demo;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import com.kyvong.entity.Product;
import com.kyvong.util.JPAUtil;

public class Demo03_QueryEntities {
	public static void main(String[] args) {
		findAll();
		findPage();
		findByParams();
	}
	
	private static void structure() {
		EntityManager em = JPAUtil.createEntityManager();

		String jpql = "SELECT o FROM Entity o...";
		TypedQuery<Entity> query = em.createQuery(jpql, Entity.class);
		List<Entity> list = query.getResultList();
		
		JPAUtil.shutdown();
	}
	
	private static void findAll() {
		EntityManager em = JPAUtil.createEntityManager();

		String jpql = "SELECT o FROM Product o";
		TypedQuery<Product> query = em.createQuery(jpql, Product.class);
		List<Product> list = query.getResultList();

		list.forEach(p -> {
			System.out.println(p.getName());
		});

		JPAUtil.shutdown();
	}
	private static void findPage() {
		int pageNo = 2;
		int pageSize = 8;
		
		EntityManager em = JPAUtil.createEntityManager();

		String jpql = "SELECT o FROM Product o";
		TypedQuery<Product> query = em.createQuery(jpql, Product.class);
		query.setFirstResult(pageNo * pageSize);
		query.setMaxResults(pageSize);
		List<Product> list = query.getResultList();

		list.forEach(p -> {
			System.out.println(p.getName());
		});

		JPAUtil.shutdown();
	}
	
	private static void findByParams() {
		double min = 5;
		double max = 10;
		String keywords = "on";
		
		EntityManager em = JPAUtil.createEntityManager();

		String jpql = "SELECT o FROM Product o "
				+ " WHERE o.unitPrice BETWEEN :min AND :max AND o.name LIKE :keywords";
		TypedQuery<Product> query = em.createQuery(jpql, Product.class);
		query.setParameter("min", min);
		query.setParameter("max", max);
		query.setParameter("keywords", keywords);
		List<Product> list = query.getResultList();

		list.forEach(p -> {
			System.out.println(p.getName());
		});

		JPAUtil.shutdown();
	}
}
