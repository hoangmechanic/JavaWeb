package com.kyvong.dao;

import java.util.Collections;
import java.util.List;

import com.kyvong.entity.Category;
import com.kyvong.entity.Product;

public class CategoryDAO extends SuperDAO<Category, Integer>{
	public List<Category> find4Randoms(){
		String jpql = "SELECT o FROM Category o WHERE size(o.products) >= 4";
		List<Category> list = this.findEntities(jpql, 0, 0);
		
		Collections.shuffle(list);
		List<Category> sublist = list.subList(0, 4);
		sublist.forEach(c->{
			List<Product> prods = c.getProducts();
			Collections.shuffle(prods);
			c.setProducts(prods.subList(0, 4));
		});
		return list;
	}
}
