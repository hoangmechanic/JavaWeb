package com.kyvong.dao;

import java.util.List;

import com.kyvong.jdbc.JdbcBean;

public abstract class SuperDAO<E, K>  extends JdbcBean<E>{
	public abstract E findById(K id);
	public abstract  List<E> findAll();
	public abstract void create(E entity);
	public abstract void update(E entity);
	public abstract void delete(K id);
}