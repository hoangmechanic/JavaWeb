package com.kyvong.dao;

import java.util.List;

import com.kyvong.entity.Order;

public class OrderDAO extends SuperDAO<Order, Integer> {
	
	public List<Order> findByCustomerId(String id) {
		String sql = "SELECT * FROM Orders WHERE CustomerId=?";
		return this.getBeans(sql, id);
	}
	
	@Override
	public Order findById(Integer id) {
		String sql = "SELECT * FROM Orders WHERE Id=?";
		return this.getBean(sql, id);
	}

	@Override
	public List<Order> findAll() {
		String sql = "SELECT * FROM Orders";
		return this.getBeans(sql);
	}

	@Override
	public void create(Order entity) {
		String sql = "INSERT INTO Orders(CustomerId, OrderDate, Address, Amount, Description) VALUES(?, ?, ?, ?, ?)";
		this.executeUpdate(sql, entity.getCustomerId(), entity.getOrderDate(), entity.getAddress(), entity.getAmount(), entity.getDescription());
		
		sql = "SELECT MAX(id) FROM Orders";
		entity.setId(this.getValue(Integer.class, sql));
	}

	@Override
	public void update(Order entity) {
		String sql = "UPDATE Orders SET CustomerId=?, OrderDate=?, Address=?, Amount=?, Description=? WHERE Id=?";
		this.executeUpdate(sql, entity.getCustomerId(), entity.getOrderDate(), entity.getAddress(), entity.getAmount(), entity.getDescription(), entity.getId());
	}

	@Override
	public void delete(Integer id) {
		String sql = "DELETE Orders WHERE Id=?";
		this.executeUpdate(sql, id);
	}
}
