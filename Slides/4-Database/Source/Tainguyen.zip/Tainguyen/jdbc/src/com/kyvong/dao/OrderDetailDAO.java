package com.kyvong.dao;

import java.util.List;

import com.kyvong.entity.OrderDetail;

public class OrderDetailDAO extends SuperDAO<OrderDetail, Integer> {

	public List<OrderDetail> findByOrderId(String id) {
		String sql = "SELECT * FROM OrderDetails WHERE OrderId=?";
		return this.getBeans(sql, id);
	}
	
	@Override
	public OrderDetail findById(Integer id) {
		String sql = "SELECT * FROM OrderDetails WHERE Id=?";
		return this.getBean(sql, id);
	}

	@Override
	public List<OrderDetail> findAll() {
		String sql = "SELECT * FROM OrderDetails";
		return getBeans(sql);
	}

	@Override
	public void create(OrderDetail entity) {
		String sql = "INSERT INTO OrderDetails(OrderId, ProductId, UnitPrice, Quantity, Discount) VALUES(?, ?, ?, ?, ?)";
		this.executeUpdate(sql, entity.getOrderId(), entity.getProductId(), entity.getUnitPrice(), entity.getQuantity(), entity.getDiscount());
		
		sql = "SELECT MAX(id) FROM OrderDetails";
		entity.setId(this.getValue(Integer.class, sql));
	}

	@Override
	public void update(OrderDetail entity) {
		String sql = "UPDATE OrderDetails SET OrderId=?, ProductId=?, UnitPrice=?, Quantity=?, Discount=? WHERE Id=?";
		this.executeUpdate(sql, entity.getOrderId(), entity.getProductId(), entity.getUnitPrice(), entity.getQuantity(), entity.getDiscount(), entity.getId());
	}

	@Override
	public void delete(Integer id) {
		String sql = "DELETE OrderDetails WHERE Id=?";
		this.executeUpdate(sql, id);
	}
}
