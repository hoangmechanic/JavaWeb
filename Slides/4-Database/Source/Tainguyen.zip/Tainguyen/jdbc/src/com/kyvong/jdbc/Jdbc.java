package com.kyvong.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Properties;

public class Jdbc {
	static Properties props = new Properties();
	static {
		try {
			props.loadFromXML(Jdbc.class.getResource("mysql.xml").openStream());
			Class.forName(props.getProperty("driver"));
		} 
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
	
	public static Connection openConnection() {
		try {
			return DriverManager.getConnection(props.getProperty("url"), props);
		} 
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
	
	public static PreparedStatement prepareStatement(Connection connection, String sql, Object...args) {
		try {
			PreparedStatement pstmt = connection.prepareStatement(sql);
			for(int i=0;i<args.length;i++) {
				pstmt.setObject(i+1, args[i]);
			}
			return pstmt;
		} 
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
	
	public static int executeUpdate(Connection connection, String sql, Object...args) {
		try {
			PreparedStatement pstmt = prepareStatement(connection, sql, args);
			return pstmt.executeUpdate();
		} 
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
	
	public static ResultSet executeQuery(Connection connection, String sql, Object...args) {
		try {
			PreparedStatement pstmt = prepareStatement(connection, sql, args);
			return pstmt.executeQuery();
		} 
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
	
	public static void closeConnection(Connection connection) {
		try {
			if(connection != null && !connection.isClosed()) {
				connection.close();
			}
		} 
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
}
