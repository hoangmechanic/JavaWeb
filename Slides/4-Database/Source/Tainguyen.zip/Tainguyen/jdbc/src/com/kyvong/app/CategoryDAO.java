package com.kyvong.app;

import java.util.List;

import com.kyvong.entity.Category;
import com.kyvong.jdbc.JdbcBean;

public class CategoryDAO extends JdbcBean<Category> {
	
	public Category findById(Integer id) {
		String sql = "SELECT * FROM Categories WHERE Id=?";
		return this.getBean(sql, id);
	}

	public List<Category> findAll() {
		String sql = "SELECT * FROM Categories";
		return this.getBeans(sql);
	}

	public void create(Category entity) {
		String sql = "INSERT INTO Categories(Name, NameVN) VALUES(?, ?)";
		this.executeUpdate(sql, entity.getName(), entity.getNameVN());
		
		sql = "SELECT MAX(id) FROM Categories";
		entity.setId(this.getValue(Integer.class, sql));
	}

	public void update(Category entity) {
		String sql = "UPDATE Categories SET Name=?, NameVN=? WHERE Id=?";
		this.executeUpdate(sql, entity.getName(), entity.getNameVN(), entity.getId());
	}

	public void delete(Integer id) {
		String sql = "DELETE Categories WHERE Id=?";
		this.executeUpdate(sql, id);
	}
}
