package com.kyvong.app;

import java.util.List;

import com.kyvong.dao.ProductDAO;
import com.kyvong.entity.Product;

public class Demo09_SuperDAO {
	public static void main(String[] args) {
		ProductDAO dao = new ProductDAO();
		List<Product> list = dao.findByCategoryId(1005);
		list.forEach(p->{
			System.out.println(p.getName());
		});
	}
}
