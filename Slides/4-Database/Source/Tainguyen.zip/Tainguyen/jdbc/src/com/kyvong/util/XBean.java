package com.kyvong.util;

import java.util.Date;
import java.util.Map;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.beanutils.ConvertUtils;
import org.apache.commons.beanutils.converters.DateConverter;

public class XBean {
	static {
		DateConverter dc = new DateConverter();
		dc.setUseLocaleFormat(true);
		dc.setPatterns(new String[] { "yyyy-MM-dd", "MM/dd/yyyy" });
		ConvertUtils.register(dc, Date.class);
	}

	public static <T> T getBean(Class<T> clazz, Map<String, ?> map) {
		try {
			T bean = clazz.newInstance();
			BeanUtils.populate(bean, map);
			return bean;
		} 
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
}
