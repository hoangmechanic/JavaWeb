package com.kyvong.dao;

import java.util.List;

import com.kyvong.entity.Customer;

public class CustomerDAO extends SuperDAO<Customer, String> {

	@Override
	public Customer findById(String id) {
		String sql = "SELECT * FROM Customers WHERE Id=?";
		return this.getBean(sql, id);
	}

	@Override
	public List<Customer> findAll() {
		String sql = "SELECT * FROM Customers";
		return this.getBeans(sql);
	}

	@Override
	public void create(Customer entity) {
		String sql = "INSERT INTO Customers(Id, Password, Fullname, Email, Photo, Activated, Admin) VALUES(?, ?, ?, ?, ?, ?, ?)";
		this.executeUpdate(sql, entity.getId(), entity.getPassword(), entity.getFullname(), entity.getEmail(), entity.getPhoto(), entity.isActivated(), entity.isAdmin());
	}

	@Override
	public void update(Customer entity) {
		String sql = "UPDATE Customers SET Password=?, Fullname=?, Email=?, Photo=?, Activated=?, Admin=? WHERE Id=?";
		this.executeUpdate(sql, entity.getPassword(), entity.getFullname(), entity.getEmail(), entity.getPhoto(), entity.isActivated(), entity.isAdmin(), entity.getId());
	}

	@Override
	public void delete(String id) {
		String sql = "DELETE Customers WHERE Id=?";
		this.executeUpdate(sql, id);
	}
}
