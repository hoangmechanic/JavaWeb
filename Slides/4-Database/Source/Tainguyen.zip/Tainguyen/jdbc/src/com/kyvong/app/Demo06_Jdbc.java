package com.kyvong.app;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.kyvong.jdbc.Jdbc;

public class Demo06_Jdbc {

	public static void main(String[] args) throws SQLException {
		executeQuery();
		executeUpdate();
	}

	private static void executeUpdate() {
		Connection connection = Jdbc.openConnection();

		String sql = "UPDATE Categories SET Name=?, NameVN=? WHERE Id=?";
		Jdbc.executeUpdate(connection, sql, "Mobile", "Điện thoại", 1009);
		
		Jdbc.closeConnection(connection);
	}

	private static void executeQuery() throws SQLException {
		Connection connection = Jdbc.openConnection();
		
		String sql = "SELECT * FROM Categories WHERE Id > ?";
		ResultSet resultSet = Jdbc.executeQuery(connection, sql, 1003);
		while(resultSet.next()) {
			int id = resultSet.getInt("Id");
			String name = resultSet.getString("Name");
			System.out.printf("%d, %s\n", id, name);
		}
		resultSet.close();
		
		Jdbc.closeConnection(connection);
	}

}
