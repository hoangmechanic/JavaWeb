package com.kyvong.dao;

import java.util.List;

import com.kyvong.entity.Product;

public class ProductDAO extends SuperDAO<Product, Integer> {
	
	public List<Product> findByCategoryId(Integer id) {
		String sql = "SELECT * FROM Products WHERE CategoryId=?";
		return this.getBeans(sql, id);
	}
	
	@Override
	public Product findById(Integer id) {
		String sql = "SELECT * FROM Products WHERE Id=?";
		return this.getBean(sql, id);
	}

	@Override
	public List<Product> findAll() {
		String sql = "SELECT * FROM Products";
		return this.getBeans(sql);
	}

	@Override
	public void create(Product entity) {
		String sql = "INSERT INTO Products(Name, UnitPrice, Image, ProductDate, Available, CategoryId, Quantity, Description, Discount, ViewCount, Special) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		this.executeUpdate(sql, entity.getName(), entity.getUnitPrice(), entity.getImage(), entity.getProductDate(), entity.isAvailable(), entity.getCategoryId(), entity.getQuantity(), entity.getDescription(), entity.getDiscount(), entity.getViewCount(), entity.isSpecial());
		
		sql = "SELECT MAX(id) FROM Products";
		entity.setId(this.getValue(Integer.class, sql));
	}

	@Override
	public void update(Product entity) {
		String sql = "UPDATE Products SET Name, UnitPrice, Image, ProductDate, Available, CategoryId, Quantity, Description, Discount, ViewCount, Special=? WHERE Id=?";
		this.executeUpdate(sql, entity.getName(), entity.getUnitPrice(), entity.getImage(), entity.getProductDate(), entity.isAvailable(), entity.getCategoryId(), entity.getQuantity(), entity.getDescription(), entity.getDiscount(), entity.getViewCount(), entity.isSpecial(), entity.getId());
	}

	@Override
	public void delete(Integer id) {
		String sql = "DELETE Products WHERE Id=?";
		this.executeUpdate(sql, id);
	}
}
