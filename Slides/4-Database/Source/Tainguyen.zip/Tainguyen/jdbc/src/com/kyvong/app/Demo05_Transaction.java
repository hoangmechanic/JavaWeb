package com.kyvong.app;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import com.kyvong.jdbc.Jdbc;

public class Demo05_Transaction {

	public static void main(String[] args) throws SQLException {
		executeUpdate();
	}

	private static void executeUpdate() throws SQLException {
		Connection connection = Jdbc.openConnection();
		
		Statement statement = connection.createStatement();
		connection.setAutoCommit(false);
		try {
			statement.executeUpdate("DELETE Categories WHERE Id=1009");
			statement.executeUpdate("DELETE Categories WHERE Id=1008");
			statement.executeUpdate("DELETE Categories Id=1007");
			statement.executeUpdate("DELETE Categories WHERE Id=1003");
			connection.commit();
		} 
		catch (Exception e) {
			connection.rollback();
		}
		connection.setAutoCommit(true);
		
		Jdbc.closeConnection(connection);
	}
}
