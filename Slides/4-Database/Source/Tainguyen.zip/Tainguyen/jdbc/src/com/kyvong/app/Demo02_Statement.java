package com.kyvong.app;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.kyvong.jdbc.Jdbc;

public class Demo02_Statement {

	public static void main(String[] args) throws SQLException {
		executeQuery();
		executeUpdate();
	}

	private static void executeQuery() throws SQLException {
		Connection connection = Jdbc.openConnection();
		
		String sql = "SELECT * FROM Categories WHERE Id > 1003";
		Statement statement = connection.createStatement();
		ResultSet resultSet = statement.executeQuery(sql);
		while(resultSet.next()) {
			int id = resultSet.getInt("Id");
			String name = resultSet.getString("Name");
			System.out.printf("%d, %s\n", id, name);
		}
		
		Jdbc.closeConnection(connection);
	}

	private static void executeUpdate() throws SQLException {
		Connection connection = Jdbc.openConnection();

		String sql = "INSERT INTO Categories(Name, NameVN) VALUES('Mobile', N'Điện thoại')";
		Statement statement = connection.createStatement();
		int count = statement.executeUpdate(sql);
		System.out.println("Số bản ghi có ảnh hưởng là " + count);
		
		Jdbc.closeConnection(connection);
	}
}
