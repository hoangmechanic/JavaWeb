package com.kyvong.dao;

import java.util.List;

import com.kyvong.entity.Category;

public class CategoryDAO extends SuperDAO<Category, Integer> {
		
	@Override
	public Category findById(Integer id) {
		String sql = "SELECT * FROM Categories WHERE Id=?";
		return this.getBean(sql, id);
	}

	@Override
	public List<Category> findAll() {
		String sql = "SELECT * FROM Categories";
		return this.getBeans(sql);
	}

	@Override
	public void create(Category entity) {
		String sql = "INSERT INTO Categories(Name, NameVN) VALUES(?, ?)";
		this.executeUpdate(sql, entity.getName(), entity.getNameVN());
		
		sql = "SELECT MAX(id) FROM Categories";
		entity.setId(this.getValue(Integer.class, sql));
	}

	@Override
	public void update(Category entity) {
		String sql = "UPDATE Categories SET Name=?, NameVN=? WHERE Id=?";
		this.executeUpdate(sql, entity.getName(), entity.getNameVN(), entity.getId());
	}

	@Override
	public void delete(Integer id) {
		String sql = "DELETE Categories WHERE Id=?";
		this.executeUpdate(sql, id);
	}
}
