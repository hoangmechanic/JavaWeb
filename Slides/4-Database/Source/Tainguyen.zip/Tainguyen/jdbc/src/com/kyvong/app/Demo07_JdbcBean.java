package com.kyvong.app;

import java.util.List;

import com.kyvong.entity.Category;
import com.kyvong.entity.Product;
import com.kyvong.jdbc.JdbcBean;

public class Demo07_JdbcBean {

	public static void main(String[] args) {
		JdbcBean<Category> jbean1 = new JdbcBean<>();
		
		String sql1 = "UPDATE Categories SET Name=?, NameVN=? WHERE Id=?";
		jbean1.executeUpdate(sql1, "Mobile", "Điện thoại", 1009);
		
		JdbcBean<Product> jbean2 = new JdbcBean<>();
		
		String sql21 = "SELECT * FROM Products WHERE UnitPrice BETWEEN ? AND ?";
		List<Product> list = jbean2.getBeans(sql21, 5.0, 9.0);
		
		String sql22 = "SELECT * FROM Products WHERE Id=?";
		Product bean = jbean2.getBean(sql22, 1005);
		
		String sql23 = "SELECT UnitPrice FROM Products WHERE Id=?";
		Double value = jbean2.getValue(Double.class, sql23, 1005);
	}
}
