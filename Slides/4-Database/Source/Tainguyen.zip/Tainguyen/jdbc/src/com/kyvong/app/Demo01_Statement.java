package com.kyvong.app;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Demo01_Statement {

	private static String driver = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
	private static String url = "jdbc:sqlserver://localhost;database=eStore";
	private static String user = "sa";
	private static String password = "songlong";
	
	static {
		try {
			Class.forName(driver);
		} 
		catch (ClassNotFoundException e) {
			throw new RuntimeException(e);
		}
	}

	public static void main(String[] args) throws SQLException {
		executeQuery();
		executeUpdate();
	}

	private static void executeQuery() throws SQLException {
		Connection connection = DriverManager.getConnection(url, user, password);
		Statement statement = connection.createStatement();
		
		String sql = "SELECT * FROM Categories WHERE Id > 1003";
		ResultSet resultSet = statement.executeQuery(sql);
		while(resultSet.next()) {
			int id = resultSet.getInt("Id");
			String name = resultSet.getString("Name");
			System.out.printf("%d, %s\n", id, name);
		}
		
		connection.close();
	}

	private static void executeUpdate() throws SQLException {
		
		Connection connection = DriverManager.getConnection(url, user, password);
		Statement statement = connection.createStatement();
		
		String sql = "INSERT INTO Categories(Name, NameVN) VALUES('Mobile', N'Điện thoại')";
		int count = statement.executeUpdate(sql);
		System.out.println("Số bản ghi có ảnh hưởng là " + count);
		
		connection.close();
	}
}
