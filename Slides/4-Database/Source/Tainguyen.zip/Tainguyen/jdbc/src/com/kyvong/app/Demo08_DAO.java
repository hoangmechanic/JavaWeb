package com.kyvong.app;

import java.sql.SQLException;
import java.util.List;

import com.kyvong.entity.Category;

public class Demo08_DAO {

	public static void main(String[] args) throws SQLException {
		CategoryDAO dao = new CategoryDAO();
		
		Category newEntity = new Category();
		newEntity.setName("New Entity");
		newEntity.setNameVN("Thực thể mới");
		dao.create(newEntity);
		
		Category category = dao.findById(1009);
		category.setNameVN("Tên mới");
		dao.update(category);
		
		dao.delete(10010);
		
		List<Category> list = dao.findAll();
		list.forEach(c->{
			System.out.println(c.getNameVN());
		});
	}
}
