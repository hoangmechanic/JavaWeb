package com.kyvong.app;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.kyvong.jdbc.Jdbc;

public class Demo04_CallableStatement {

	public static void main(String[] args) throws SQLException {
		executeQuery();
		executeUpdate();
	}

	private static void executeQuery() throws SQLException {
		Connection connection = Jdbc.openConnection();
		
		String sql = "{call spSelectById(?)}";
		CallableStatement statement = connection.prepareCall(sql);
		statement.setObject(1, 1003);
		ResultSet resultSet = statement.executeQuery();
		while(resultSet.next()) {
			int id = resultSet.getInt("Id");
			String name = resultSet.getString("Name");
			System.out.printf("%d, %s\n", id, name);
		}
		
		Jdbc.closeConnection(connection);
	}

	private static void executeUpdate() throws SQLException {
		Connection connection = Jdbc.openConnection();
		
		String sql = "{call spUpdateCategory(?, ?, ?)}";
		PreparedStatement statement = connection.prepareStatement(sql);
		statement.setObject(1, "Mobile");
		statement.setObject(2, "Điện thoại");
		statement.setObject(3, 1009);
		int count = statement.executeUpdate();
		System.out.println("Số bản ghi có ảnh hưởng là " + count);
		
		Jdbc.closeConnection(connection);
	}
}
