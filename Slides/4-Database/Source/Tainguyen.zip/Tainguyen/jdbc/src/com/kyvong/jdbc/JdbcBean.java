package com.kyvong.jdbc;

import java.lang.reflect.ParameterizedType;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.kyvong.util.XBean;

public class JdbcBean<Bean> {
	protected Connection connection = Jdbc.openConnection();
	
	@Override
	protected void finalize() throws Throwable {
		Jdbc.closeConnection(connection);
		super.finalize();
	}
	
	public ResultSet executeQuery(String sql, Object...args) {
		return Jdbc.executeQuery(connection, sql, args);
	}
	
	public int executeUpdate(String sql, Object...args) {
		return Jdbc.executeUpdate(connection, sql, args);
	}

	public List<Bean> getBeans(String sql, Object...args) {
		try {
			ResultSet rs = executeQuery(sql, args);
		    List<Bean> beans = new ArrayList<>();
			while(rs.next()) {
				Bean bean = XBean.getBean(getBeanClass(), this.recordToMap(rs));
				beans.add(bean);
			}
		    rs.close();
	        return beans;
		} 
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
	
	public Bean getBean(String sql, Object...args) {
		List<Bean> list = getBeans(sql, args);
		if(list.size() == 0) {
			return null;
		}
		return list.get(0);
	}
	
	@SuppressWarnings("unchecked")
	public <T> T getValue(Class<T> returnTypeClass, String sql, Object...args) {
		try {
			T value = null;
			ResultSet rs = executeQuery(sql, args);
		    if(rs.next()) {
		    	value = (T) rs.getObject(1);
		    }
		    rs.close();
		    return value;
		} 
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
	
	private Map<String, Object> recordToMap(ResultSet rs) throws SQLException {
		ResultSetMetaData meta = rs.getMetaData();
	    int columns = meta.getColumnCount();
    	Map<String, Object> map = new HashMap<String, Object>();
        for(int i = 1; i <= columns; ++i){
        	String name = meta.getColumnName(i);
        	name = name.substring(0, 1).toLowerCase() + name.substring(1);
        	Object value = rs.getObject(i);
            map.put(name, value);
        }
        return map;
	}
	
	@SuppressWarnings("unchecked")
	private Class<Bean> getBeanClass(){
		ParameterizedType type = (ParameterizedType) getClass().getGenericSuperclass();
		return (Class<Bean>) type.getActualTypeArguments()[0];
	}
}
