package com.jdbc;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Types;
import java.util.Date;

public class Jdbc3 {
	private static String driver = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
	private static String url = "jdbc:sqlserver://localhost;database=EShopV10";
	private static String user = "sa";
	private static String password = "songlong";

	public static void main(String[] args) {
		//update();
		query2();
	}

	private static void update() {
		String sql = "{CALL spInsertCategory(?, ?, ?)}";
		try {
			Class.forName(driver);
			Connection connection = DriverManager.getConnection(url, user, password);
			CallableStatement statement = connection.prepareCall(sql);
			statement.setString(1, "Clock");
			statement.setString(2, "Đồng hồ");
			statement.registerOutParameter(3, Types.INTEGER);
			statement.executeUpdate();
			int id = statement.getInt(3);
			connection.close();
			System.out.println(id);
		} 
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private static void query() {
		String sql = "{CALL spSearchProducts(?, ?)}";
		try {
			Class.forName(driver);
			Connection connection = DriverManager.getConnection(url, user, password);
			CallableStatement statement = connection.prepareCall(sql);
			statement.setDouble(1, 5.0);
			statement.setDouble(2, 10);
			ResultSet resultSet = statement.executeQuery();
			while(resultSet.next()) {
				String name = resultSet.getString("Name");
				double price = resultSet.getDouble("UnitPrice");
				int qty = resultSet.getInt("Quantity");
				Date date = resultSet.getDate("ProductDate");
				System.out.printf("%s, %.2f\n", name, price);
			}
			connection.close();
		} 
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private static void query2() {
		String sql = "{CALL spRevenueByCategory()}";
		try {
			Class.forName(driver);
			Connection connection = DriverManager.getConnection(url, user, password);
			CallableStatement statement = connection.prepareCall(sql);
			ResultSet resultSet = statement.executeQuery();
			while(resultSet.next()) {
				String category = resultSet.getString("Category");
				double price = resultSet.getDouble("Revenue");
				int qty = resultSet.getInt("Quantity");
				System.out.printf("%s, %.2f, %d\n", category, price, qty);
			}
			connection.close();
		} 
		catch (Exception e) {
			e.printStackTrace();
		}
	}
}
