package com.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Date;

public class Jdbc2 {
	private static String driver = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
	private static String url = "jdbc:sqlserver://localhost;database=EShopV10";
	private static String user = "sa";
	private static String password = "songlong";

	public static void main(String[] args) {
		//update();
		query();
	}

	private static void update() {
		String sql = "INSERT INTO Categories(Name, NameVN) VALUES(?, ?)";
		try {
			Class.forName(driver);
			Connection connection = DriverManager.getConnection(url, user, password);
			PreparedStatement statement = connection.prepareStatement(sql);
			statement.setString(1, "Marker");
			statement.setString(2, "Bút viết bảng trắng");
			statement.executeUpdate();
			connection.close();
		} 
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private static void query() {
		String sql = "SELECT * FROM Products WHERE UnitPrice BETWEEN ? AND ?";
		try {
			Class.forName(driver);
			Connection connection = DriverManager.getConnection(url, user, password);
			PreparedStatement statement = connection.prepareStatement(sql);
			statement.setDouble(1, 5.0);
			statement.setDouble(2, 10);
			ResultSet resultSet = statement.executeQuery();
			while(resultSet.next()) {
				String name = resultSet.getString("Name");
				double price = resultSet.getDouble("UnitPrice");
				int qty = resultSet.getInt("Quantity");
				Date date = resultSet.getDate("ProductDate");
				System.out.printf("%s, %.2f\n", name, price);
			}
			connection.close();
		} 
		catch (Exception e) {
			e.printStackTrace();
		}
	}
}
