package com.nhatnghe.app;

import java.util.List;

import javax.persistence.TypedQuery;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.nhatnghe.entity.Category;
import com.nhatnghe.entity.HiberUtil;
import com.nhatnghe.entity.Product;

public class Test {

	public static void main(String[] args) {
		//execute();
		//query();
		//query2();
		//query3();
		query4();
	}

	private static void query4() {
		String hql = "SELECT p FROM Product p WHERE p.id=1005";
		Session session = HiberUtil.getSessionFactory().openSession();
		
		
		TypedQuery<Category> query = session.createQuery(hql, Category.class);
		Category a = query.getSingleResult();
		
		System.out.printf("%s, %s\n", a.getName(), a.getNameVN());
		
		HiberUtil.shutdown();
	}

	private static void query3() {
		Session session = HiberUtil.getSessionFactory().openSession();
		
		String hql = "SELECT p.name, p.unitPrice FROM Product p WHERE p.id=1005";
		TypedQuery<Object[]> query = session.createQuery(hql, Object[].class);
		Object[] a = query.getSingleResult();
		
		System.out.printf("%s, %.2f\n", a[0], a[1]);
		
		HiberUtil.shutdown();
	}

	private static void query2() {
		Session session = HiberUtil.getSessionFactory().openSession();
		
		String hql = "SELECT p.name, p.unitPrice, p.category.nameVN FROM Product p";
		TypedQuery<Object[]> query = session.createQuery(hql, Object[].class);
		List<Object[]> list = query.getResultList();
		
		for(Object[] a : list) {
			System.out.printf("%s, %.2f, %s\n", a[0], a[1], a[2]);
		}
		
		HiberUtil.shutdown();
	}

	private static void query() {
		Session session = HiberUtil.getSessionFactory().openSession();
		
		String hql = "SELECT p FROM Product p";
		TypedQuery<Product> query = session.createQuery(hql, Product.class);
		List<Product> list = query.getResultList();
		
		for(Product p : list) {
			System.out.printf("%s, %.2f\n", p.getName(), p.getUnitPrice());
		}
		
		HiberUtil.shutdown();
	}

	private static void execute() {
		Category entity = new Category();
		entity.setId(1269);
		//entity.setName("Chair");
		//entity.setNameVN("Ghế đẩu");
		
		Session session = HiberUtil.getSessionFactory().openSession();
		Transaction transaction = session.beginTransaction();
		try {
			//session.persist(entity);
			//session.merge(entity);
			session.remove(entity);
			transaction.commit();
		} 
		catch (Exception e) {
			transaction.rollback();
		}
		HiberUtil.shutdown();
	}

}
