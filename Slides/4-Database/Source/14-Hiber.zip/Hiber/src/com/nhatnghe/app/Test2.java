package com.nhatnghe.app;

import java.util.List;

import javax.persistence.TypedQuery;

import org.hibernate.Session;

import com.nhatnghe.entity.Category;
import com.nhatnghe.entity.HiberUtil;
import com.nhatnghe.entity.Product;

public class Test2 {

	public static void main(String[] args) {
		//params();
		//paginate();
		//queryOne();
		//relationship1N();
		relationshipN1();
	}

	private static void relationshipN1() {
		Session session = HiberUtil.getSessionFactory().openSession();
		
		Product p = session.find(Product.class, 1005);
		System.out.println(p.getName());
		
		Category category = p.getCategory();
		System.out.println(" + Loại: " + category.getNameVN());
	}

	private static void relationship1N() {
		Session session = HiberUtil.getSessionFactory().openSession();
		
		Category c = session.find(Category.class, 1003);
		System.out.println(c.getNameVN());
		List<Product> list = c.getProducts();
		for(Product p : list) {
			System.out.println(" + " + p.getName());
		}
		HiberUtil.shutdown();
	}

	private static void queryOne() {
		Session session = HiberUtil.getSessionFactory().openSession();
		
		//Product p = session.find(Product.class, 1005);
		//Product p = session.get(Product.class, 1005);
		//Product p = session.load(Product.class, 1005);
		
		Product p = new Product();
		p.setId(1005);
		session.refresh(p);
		
		System.out.println(p.getName());
		
		HiberUtil.shutdown();
	}

	private static void paginate() {
		int pageNo = 2;
		int pageSize = 8;
		
		Session session = HiberUtil.getSessionFactory().openSession();
		
		String hql = "FROM Product";
		TypedQuery<Product> query = session.createQuery(hql, Product.class);
		query.setFirstResult(pageNo*pageSize);
		query.setMaxResults(pageSize);
		List<Product> list = query.getResultList();
		
		for(Product p : list) {
			System.out.println(p.getName());
		}
		
		HiberUtil.shutdown();
		
	}

	private static void params() {
		Session session = HiberUtil.getSessionFactory().openSession();
		
		String hql = "FROM Product p "
				+ " WHERE p.category.id = :id AND p.unitPrice > :min";
		TypedQuery<Product> query = session.createQuery(hql, Product.class);
		query.setParameter("id", 1003);
		query.setParameter("min", 10.0);
		List<Product> list = query.getResultList();
		
		for(Product p : list) {
			System.out.println(p.getName());
		}
		
		HiberUtil.shutdown();
	}

}
