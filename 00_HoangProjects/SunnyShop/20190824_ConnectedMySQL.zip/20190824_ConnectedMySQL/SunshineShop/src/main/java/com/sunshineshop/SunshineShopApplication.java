package com.sunshineshop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SunshineShopApplication {

	public static void main(String[] args) {
		SpringApplication.run(SunshineShopApplication.class, args);
	}

}
