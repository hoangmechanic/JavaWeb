package com.sunnyshop.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.sunnyshop.dao.CategoryDAO;
@Component
public class GlobalInterceptor extends HandlerInterceptorAdapter {

	@Autowired
	CategoryDAO cDao;

	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		super.postHandle(request, response, handler, modelAndView);
		request.setAttribute("cates", cDao.findAll());
	}

	
}
