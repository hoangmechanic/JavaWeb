package com.sunnyshop.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.sunnyshop.dao.CategoryDAO;
import com.sunnyshop.dao.ProductDAO;
import com.sunnyshop.entity.Category;
import com.sunnyshop.entity.Product;

@Controller
public class ProductController {

	@Autowired
	CategoryDAO cdao;

	@Autowired
	ProductDAO pdao;

	@RequestMapping("/prod/list-by-cate/{id}")
	public String listByCategory(Model model, @PathVariable("id") Integer id) {
		Category category = cdao.findById(id);
		List<Product> list = new ArrayList<>();
		if (category != null) {
			list = category.getProducts();
		}
		model.addAttribute("prods", list);
		return "product/list";
	}

	@RequestMapping("/prod/list-by-spec/{key}")
	public String listBySpecials(Model model, @PathVariable("key") String key) {
		List<Product> prods = pdao.findSpecials(key);
		model.addAttribute("prods", prods);
		return "product/list";
	}
}
