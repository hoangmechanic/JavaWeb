package com.sunnyshop.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.TypedQuery;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Repository;
//import org.springframework.transaction.annotation.Transactional;

import com.sunnyshop.entity.Category;
import com.sunnyshop.entity.OrderDetail;
import com.sunnyshop.entity.Product;

//@Transactional
//@Repository
public class ProductDAO {
//	@Autowired
	SessionFactory factory;
	
//	public List<Product> findAll(){
//		Session session = factory.getCurrentSession();
//		String hql = "FROM Product";
//		TypedQuery<Product> query = session.createQuery(hql, Product.class);
//		List<Product> list = query.getResultList();
//		return list;
//	}
//
//	public Product findById(Integer id) {
//		Session session = factory.getCurrentSession();
//		Product entity = session.find(Product.class, id);
//		return entity;
//	}

	Map<Integer,Product> map = new HashMap<>();

	public ProductDAO() {
		List<OrderDetail> orderDetails = new ArrayList<>();
		Product product = new Product(new Integer(1001),"Aniseed Syrup Star",190.0,"1001.jpg",new Date(1991), true, 1000,"Alibaba", 0, 1, false, new Category(), orderDetails);
		map.put(new Integer(1001),product);
	}

	public List<Product> findAll(){
		return new ArrayList<>(map.values());
	}
	
	public Product create(Product entity){
		Session session = factory.getCurrentSession();
		session.save(entity);
		return entity;
	}
	
	public void update(Product entity) {
		Session session = factory.getCurrentSession();
		session.update(entity);
	}
	
	public void delete(Integer id) {
		Session session = factory.getCurrentSession();
		session.delete(session.find(Product.class, id));
	}
}
