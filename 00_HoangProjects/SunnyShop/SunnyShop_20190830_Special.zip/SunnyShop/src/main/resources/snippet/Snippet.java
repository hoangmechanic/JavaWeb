package snippet;

public class Snippet {
	public static void main(String[] args) {
		<dependency>
		    <groupId>org.hibernate</groupId>
		    <artifactId>hibernate-core</artifactId>
		    <version>5.4.1.Final</version>
		</dependency>
	}
}

