$(document).ready(function(){
	$("[data-id-add-shopping-cart]").click(function(){
		id = $(this).attr("data-id-add-shopping-cart");
		$.ajax({
			url:"/cart/add/"+id,
			success:function(response){
				$("#cart-cnt").html(response.count);
				$("#cart-amt").html(response.amount);
			}
		});
	});
});