package com.sunnyshop.dao;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.persistence.TypedQuery;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.sunnyshop.entity.Product;

@Transactional
@Repository
public class ProductDAO {
	@Autowired
	SessionFactory factory;
	
	public List<Product> findAll(){
		Session session = factory.getCurrentSession();
		String hql = "FROM Product";
		TypedQuery<Product> query = session.createQuery(hql, Product.class);
		List<Product> list = query.getResultList();
		return list;
	}

	public Product findById(Integer id) {
		Session session = factory.getCurrentSession();
		Product entity = session.find(Product.class, id);
		return entity;
	}
	
	public Product create(Product entity){
		Session session = factory.getCurrentSession();
		session.save(entity);
		return entity;
	}
	
	public void update(Product entity) {
		Session session = factory.getCurrentSession();
		session.update(entity);
	}
	
	public void delete(Integer id) {
		Session session = factory.getCurrentSession();
		session.delete(session.find(Product.class, id));
	}
	
	public  List<Product> findSpecials(String key) {
		Session session = factory.getCurrentSession();
		String hql = "FROM Product p";
		int maxProduct = -1;
		switch (key) {
			case "special":
				hql = "FROM Product p WHERE p.special=true";
				break;
			case "new":
				// hql = "FROM Product p WHERE p.productDate >'2000-01-01'";
				hql = "FROM Product p WHERE p.productDate > '" + getDateString(changeMonth(new Date(), -1))+"'";
				break;
			case "saleOff":
				hql = "FROM Product p "
						+ " WHERE p.discount > 0 ORDER BY p.discount DESC";
				break;
			case "mostView":
				hql = "FROM Product p "
						+ " WHERE p.viewCount > 0 ORDER BY p.viewCount DESC";
				maxProduct = 12;
				break;
		}
		TypedQuery<Product> query = session.createQuery(hql, Product.class);
		if (maxProduct > -1) {
			query.setMaxResults(maxProduct);
		}
		List<Product> list = query.getResultList();
		return list;
	}

	private String getTodayString() {
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date today = new Date();
		System.out.println("############ today: " + dateFormat.format(today));
		return dateFormat.format(today);
	}

	private Date changeDate(Date today, int days) {
		Calendar c = Calendar.getInstance(); 
		c.setTime(today); 
		c.add(Calendar.DATE, days);
		return c.getTime();
	}

	private Date changeMonth(Date today, int month) {
		Calendar c = Calendar.getInstance(); 
		c.setTime(today); 
		c.add(Calendar.MONTH, month);
		return c.getTime();
	}

	private String getDateString(Date date) {
		String strDate = new SimpleDateFormat("yyyy-MM-dd").format(date);
		System.out.println("############ Milestone: "+ strDate);
		return strDate;
	}


}
