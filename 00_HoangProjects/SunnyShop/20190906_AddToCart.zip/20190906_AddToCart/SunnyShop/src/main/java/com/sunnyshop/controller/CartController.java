package com.sunnyshop.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sunnyshop.service.CartService;

@Controller
public class CartController {

	@Autowired
	CartService cart;

	@ResponseBody
	@RequestMapping("/cart/add/{id}")
	public Map<String,Object> add(@PathVariable("id") Integer id){
		System.out.println("########## here");
		cart.add(id);
		
		Map<String, Object> map = new HashMap<>();
		map.put("count", cart.getCount());
		map.put("amount", cart.getAmount());
		
		return map;
	}

}
