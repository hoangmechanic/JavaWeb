package com.sunnyshop.service;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.context.annotation.SessionScope;

import com.sunnyshop.dao.ProductDAO;
import com.sunnyshop.entity.Product;

//@SessionScope
@Service("cart")
public class CartService {

	@Autowired
	ProductDAO dao;

	Map<Integer, Product> map = new HashMap<>();

	public void add(Integer id) {
		Product p = map.get(id);
		if (p == null) {
			p = dao.findById(id);
			p.setQuantity(1);
			map.put(id, p);
		} else {
			p.setQuantity(p.getQuantity() + 1);
		}
	}

	public int getCount() {
		int count = 0;
		for(Product p : map.values()) {
			count += p.getQuantity();
		}
		return count;
	}

	public double getAmount() {
		double amount = 0;
		for(Product p : map.values()) {
			amount += p.getQuantity() * p.getUnitPrice() * (1-p.getDiscount());
		}
		return amount;
	}

}
